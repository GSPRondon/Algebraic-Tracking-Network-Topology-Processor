//Por Gustavo: Arquivo com as estruturas de dados utilizadas no código
#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H

enum BOOLEAN{
    True = 1, //Define o valor verdadeiro para testes booleanos
    False = 0 //Define o valor falso para testes booleanos
};
typedef enum BOOLEAN BOOL;

/**
 * Específica a métrica de clock para calcular o tempo de execução em segundos.
 */
#ifdef CLOCKS_PER_SEC
 static const double CLOCK_TICKS_PER_SECOND = (double)CLOCKS_PER_SEC;
 #elif defined(CLK_TCK)
 static const double CLOCK_TICKS_PER_SECOND = (double)CLK_TCK;
 #else
 static const double CLOCK_TICKS_PER_SECOND = 1000000.0;
 #endif
//-------------------------------------------------------------------------------
//Estruturas de dados para os componentes da rede
//-------------------------------------------------------------------------------
//Dados de medição
typedef struct{
    int tipo; //Tipo da medição:
             /* 0 - Fluxo de potência;
                1 - Injeção de potência;
                2 - Fluxo de corrente;
                3 - Injeção de corrente;
                4 - Tensão;
             */ 
    int IDbarraDe;
    int IDbarraPara;
} DMED;
//Dados de barra
typedef struct{
    //Dados intrínsecos da barra
    int numeroBarra;
    int IDbarra;
    int subestacao;
    int IDsubestacao;
    int numeroBarraAssociada;
    int IDbarraAssociada;
    int quantidadeRamosAdjacentes;
    int quantidadeBarrasAdjacentes;
    int *IDramosAdjacentes;
    int *IDbarrasAdjacentes;
    int quantidadeChavesAdjacentes;
    int *IDchavesAdjacentes;
    int IDgerador;
    int IDcarga;
    int IDshunt;
    int quantidadeMedidores;
    int *IDmedidores;
    //Dados da barra após as associações
    int quantidadeBarrasAdjacentesAssociadas;
    int *IDbarrasAdjacentesAssociadas;
    int quantidadeRamosAssociados;
    int *IDramosAssociados;
    int quantidadeGeradoresAssociados;
    int *IDgeradoresAssociados;
    int quantidadeCargasAssociadas;
    int *IDcargasAssociadas;
    int quantidadeShuntsAssociados;
    int *IDshuntsAssociados;
    int quantidadeMedidoresAssociados;
    int *IDmedidoresAssociados;
    //Dados da barra após o tracking
    int quantidadeBarrasTracking;
    int *IDbarrasTracking;
    int quantidadeRamosTracking;
    int *IDramosTracking;
    int quantidadeGeradoresTracking;
    int *IDgeradoresTracking;
    int quantidadeCargasTracking;
    int *IDcargasTracking;
    int quantidadeShuntsTracking;
    int *IDshuntsTracking;
    int quantidadeMedidoresTracking;
    int *IDmedidoresTracking;
    //Identificação do próximo nó na árvore de fatoração
    int proximoNo;
    BOOL energizada; //Define se a barra está energizada ou não: 0 - não energizada; 1 - energizada
    int IDcaminhoFatoracao; //Indica o ID do caminho de fatoração do qual a barra faz parte
    int quantidadeMedidas;
    DMED *medidas;
    BOOL modificadaTracking; //Indica se uma barra foi modificada no configurador tracking
    BOOL caminhoTracking; //Indica se uma barra pertence ao caminho 
    BOOL modificadaShunt; //Indica se uma barra teve apenas o número de shunts alterados
    BOOL barraVizinhaTracking; //Indica se uma barra está na vizinhança de uma barra que foi modificada
} DBAR;

//Dados de ramo
typedef struct{
    int numeroRamo;
    int IDramo;
    int barraDe;
    int IDbarraDe;
    int barraDeAssociada;
    int barraDeTracking;
    int IDbarraDeAssociada;
    int IDbarraDeTracking;
    int barraPara;
    int IDbarraPara;
    int barraParaAssociada;
    int barraParaTracking;
    int IDbarraParaAssociada;
    int IDbarraParaTracking;
    int ligado; //Define se o ramo está ligado ou não: 0 - desligado; 1 - ligado
    int tipo; //Define o tipo do ramo: 0 - transformador; 1 - linha de transmissão; 2 - regulador de tensão
} DRAM;

//Dados de chave
typedef struct{
    int numeroChave;
    int IDchave;
    int IDsubestacao;
    int barraDe;
    int IDbarraDe;
    int barraDeAssociada;
    int IDbarraDeAssociada;
    int barraPara;
    int IDbarraPara;
    int barraParaAssociada;
    int IDbarraParaAssociada;
    int status; //Define se a chave está aberta ou não: 0 - aberta; 1 - fechada
    int statusAtualizado;
} DCHAVE;

//Dados de gerador
typedef struct{
    int numero;
    int IDgerador;
    int barra;
    int IDbarra;
    int barraAssociada;
    int IDbarraAssociada;
    int ligado; //Define se o gerador está ligado ou não: 0 - desligado; 1 - ligado
    int IDsubestacao;
    int IDmedidor; // ID do medidor vinculado a esse componente
    BOOL possuiMedidaPotencia; //Indica se a medição associada a esse componente está habilitada
    BOOL possuiMedidaCorrente;
} DGEN;

//Dados de carga
typedef struct{
    int numero;
    int IDcarga;
    int barra;
    int IDbarra;
    int barraAssociada;
    int IDbarraAssociada;
    int ligado; //Define se a carga está ligada ou não: 0 - desligada; 1 - ligada
    int IDsubestacao;
    int IDmedidor; // ID do medidor vinculado a esse componente
    BOOL possuiMedidaPotencia; //Indica se a medição associada a esse componente está habilitada
    BOOL possuiMedidaCorrente;
} DCARGA;

//Dados de shunt
typedef struct{
    int numero;
    int IDshunt;
    int barra;
    int IDbarra;
    int barraAssociada;
    int IDbarraAssociada;
    int ligado; //Define se o shunt está ligado ou não: 0 - desligado; 1 - ligado
    int IDsubestacao;
    int tipo; //Defino o tipo do shunt: 0 - compensador síncrono; 1 - capacitor; 2 - reator
    int IDmedidor; // ID do medidor vinculado a esse componente
    BOOL possuiMedidaPotencia; //Indica se a medição associada a esse componente está habilitada
    BOOL possuiMedidaCorrente;
} DSHUNT;

//Dados do transformador de potencial
typedef struct{
     int barra;
     int IDbarra;
     int barraAssociada;
     int IDbarraAssociada;
} DTP;

//Dados do transformador de Corrente
typedef struct{
    int barraDe;
    int IDbarraDe;
    int barraDeAssociada;
    int IDbarraDeAssociada;
    int barraPara;
    int IDbarraPara;
    int barraParaAssociada;
    int IDbarraParaAssociada;
} DTC;

//Dados do arranjo de medição
typedef struct{
    int numeroArranjo;
    int IDarranjo;
    int tipoMedidor; //Define o tipo do medidor: 0 - potência; 1 - tensão; 2 - corrente
    DTP TP; //Dados do transformador de potência
    DTC TC; //Dados do transformador de corrente
    int tipoEquipamento; /*
                            * Define o tipo de equipamento ao qual o medidor está vinculado:
                            * 0 - linha de transmissão;
                            * 1 - transformador;
                            * 2 - carga;
                            * 3 - equipamento shunt;
                            * 4 - gerador;
                            */
    int barraLTR; //Barra "para" da linha de transmissão ou transformador 
    int IDbarraLTR;
    int barraLTRAssociada;
    int IDbarraLTRAssociada;
    int IDshunt; 
    int IDsubestacao;
} DARRANJO;    

//Estrutura da árvore de fatoração
typedef struct{
    int tamanho;
    int *no;
    int *proximoNo;
} ARVORE;

//Lista encadeada para armazenar linhas da matriz no formato esparso
typedef struct NO{
    int IDcoluna;
    double valor;
    struct NO *proximo;
} LISTA;

//Struct da linha de uma matriz no formato esparso
typedef struct{
    int IDlinha;
    int tamanho;
    LISTA *head; //head da lista encadeada
} LINHA;

//Struct para armazenar as barras pertencentes a um caminho de fatoração
typedef struct{
    int tamanho;
    BOOL energizado; //Define se o caminho está energizado ou não
    int *IDbarras;
} CAMINHO;

//Dados da subestação
typedef struct{
    int numeroSubestacao;
    int IDsubestacao;
    int quantidadeBarras;
    int *IDbarras;
    int quantidadeBarrasRelevantes;
    int *IDbarrasRelevantes;
    int quantidadeBarrasIrrelevantes;
    int *IDbarrasIrrelevantes;
    int quantidadeBarrasAssociadas;
    int *IDbarrasAssociadas;
    CAMINHO *listaCaminhosFatoracao;
    int quantidadeChaves;
    int *IDchavesReferencia;
    int *IDchaves;
    LINHA *Href;
    LINHA *Hf;
    int quantidadeMedidores;
    int *IDmedidores;
    int quantidadeGeradores;
    int *IDgeradores;
    int quantidadeCargas;
    int *IDcargas;
    int quantidadeShunts;
    int *IDshunts;
    LINHA *fatores;
    ARVORE arvoreFatoracao;
} DSUBESTACAO;

#endif