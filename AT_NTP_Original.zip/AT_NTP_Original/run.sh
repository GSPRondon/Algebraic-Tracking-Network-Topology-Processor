cd "$(dirname "$0")"


meson setup ./build --buildtype=release && ninja -C ./build || exit


for j in {1..1}; do
    echo "[BASH] Sample: $j"
    chave=1  
    ./build/ATNTP "$chave"  
done

