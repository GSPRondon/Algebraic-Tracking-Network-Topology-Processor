#ifndef funcoesTopologia_H
#define funcoesTopologia_H
BOOL existeNoVetor(int *vetor, int tamanhoVetor, int valor);
BOOL existeNoConjunto(int *vetor1, int *vetor2, int tamanhoVetor1, int tamanhoVetor2);
int retornaIDmenorBarra(DBAR *dadosBarra, int *IDbarras, int numeroBarrasCaminho);
void listaCaminhosFatoracaoSubestacao(DSUBESTACAO *dadosSubestacao, int IDsubestacao);
int listaCaminhosEVerificaIlhaEnergizada(DBAR *dadosBarra, CAMINHO *caminhoFatoracao, LINHA *barrasAssociadas);
void completaDadosBarra(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, CAMINHO **caminhoFatoracao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes);
void completaDadosSubestacao(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes);
void completaDadosRede(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, CAMINHO **caminhoFatoracao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes);
void associaBarrasPorSubestacao(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int IDsubestacao);
void PNS(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes);
void constroiMatrizY(DBAR *dadosBarra, DRAM *dadosRamo, LINHA **matrizY, LINHA **barrasAssociadas, int numeroBarras);
LINHA *PNR(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas);
void processaMedicao(DBAR *dadosBarra, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt,  DARRANJO *dadosArranjo, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao);
LINHA *configuradorRede(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas);   
LINHA *identificaSubestacoesModificadas(DCHAVE *dadosChave, int numeroChaves);
void associaBarrasPorSubestacaoTracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **barrasAfetadas, LINHA **ramosAfetados,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int IDsubestacao);
LINHA *PNStracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA *subestacoesModificadas, LINHA *ramosAfetados,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, 
                            int numeroCargas, int numeroShunts, int numeroArranjos, int numeroSubestacoes);
LINHA *identificaBarrasCaminhoFatoracao(DBAR *dadosBarra, LINHA *barrasAfetadas);
void aplicaModificacoesMatrizY(LINHA *matrizYrecuperada, LINHA *barrasAfetadas, LINHA *ramosAfetados, LINHA *barrasAssociadas, DBAR *dadosBarra, DRAM *dadosRamo);   
void constroiMatrizYtracking(LINHA *matrizY, LINHA *barrasAfetadas, LINHA *barrasAssociadas, DBAR *dadosBarra, DRAM *dadosRamo);  
void PNRtracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA *subestacoesModificadas, LINHA *barrasAfetadas, LINHA *ramosAfetados,
                            LINHA **matrizY, LINHA **fatoresY, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, 
                            int numeroCargas, int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas);                                              
double configuradorTracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas);                       
#endif