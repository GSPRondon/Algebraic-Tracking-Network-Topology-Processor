#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <omp.h>

#include "data_structures.h"
#include "funcoesLeitura.h"
#include "funcoesMatematicas.h"
#include "funcoesTopologia.h"
#include "funcoesSaida.h"

void main(int argc, char **argv){
    //------------------------------------------------------------------------------------------------
    //Variable initialization
    //------------------------------------------------------------------------------------------------
    int numeroBarras = 0;
    int numeroRamos = 0;
    int numeroChaves = 0;
    int numeroGeradores = 0;
    int numeroCargas = 0;
    int numeroShunts = 0;
    int numeroArranjos = 0;
    int numeroSubestacoes = 0;
    int numeroMedicoes = 0;
    int numeroIlhas = 0;
    char *pasta = NULL;
    DBAR *dadosBarra;
    DRAM *dadosRamo;
    DCHAVE *dadosChave;
    DGEN *dadosGerador;
    DCARGA *dadosCarga;
    DSHUNT *dadosShunt;
    DARRANJO *dadosArranjo;
    DSUBESTACAO *dadosSubestacao;
    CAMINHO *caminhosFatoracao = NULL;
    LINHA *matrizY = NULL;
    LINHA *fatoresY = NULL;
    LINHA *barrasAssociadas = NULL;

    double tempoGastoCR;
    double tempoGastoTR;
    double tempoPNRT_PAMT;

    int arg = atoi(argv[1]);
    //------------------------------------------------------------------------------------------------
    //Reading input data
    //------------------------------------------------------------------------------------------------
    pasta = leituraDados(&dadosBarra, &dadosRamo, &dadosChave, &dadosGerador, &dadosCarga,
                            &dadosShunt, &dadosArranjo, &dadosSubestacao, &numeroBarras,
                            &numeroRamos, &numeroChaves, &numeroGeradores, &numeroCargas,
                            &numeroShunts, &numeroArranjos, &numeroSubestacoes, arg);
    //------------------------------------------------------------------------------------------------
    //Creating and filling the program’s data structures
    //------------------------------------------------------------------------------------------------
    completaDadosRede(&dadosBarra, &dadosRamo, &dadosChave, &dadosGerador, &dadosCarga,
                            &dadosShunt, &dadosArranjo, &dadosSubestacao, &caminhosFatoracao, numeroBarras,
                            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes);
    //------------------------------------------------------------------------------------------------
    //Initialization of the Algebraic Tracking Network Topology Processor
    //------------------------------------------------------------------------------------------------
    double start_timeCR = omp_get_wtime();
    barrasAssociadas = configuradorRede(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                                            dadosShunt, dadosArranjo, dadosSubestacao, &matrizY, &fatoresY, caminhosFatoracao,
                                            numeroBarras,numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                                            numeroShunts, numeroArranjos, numeroSubestacoes, &numeroIlhas);
    double elapsedCR = omp_get_wtime() - start_timeCR;
    //------------------------------------------------------------------------------------------------
    //Printing the output files
    //------------------------------------------------------------------------------------------------
    imprimeSaida(dadosBarra, barrasAssociadas, caminhosFatoracao, dadosRamo, dadosGerador, dadosCarga, dadosShunt,
                        numeroRamos, numeroGeradores, numeroCargas, numeroShunts);
    //------------------------------------------------------------------------------------------------
    //Application of the Algebraic Tracking Network Topology Processor for system topology update
    //------------------------------------------------------------------------------------------------
    double start_timeTR = omp_get_wtime();
    tempoPNRT_PAMT = configuradorTracking(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, &matrizY, &fatoresY, barrasAssociadas, caminhosFatoracao,
                            numeroBarras,numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes, &numeroIlhas);
    double elapsedTR = omp_get_wtime() - start_timeTR;
    //------------------------------------------------------------------------------------------------
    //Printing the output files
    //------------------------------------------------------------------------------------------------
    imprimeSaidaTracking(dadosBarra, barrasAssociadas, caminhosFatoracao, dadosRamo, dadosGerador, dadosCarga, dadosShunt,
                        numeroRamos, numeroGeradores, numeroCargas, numeroShunts);  
    //------------------------------------------------------------------------------------------------                      
    //Printing the execution times
    //------------------------------------------------------------------------------------------------
    FILE *arquivo;
    arquivo = fopen("Tempos.csv","a");
    fprintf(arquivo,"%.10lf,%.10lf,%.10lf\n",elapsedCR,elapsedTR,tempoPNRT_PAMT);
    fclose(arquivo);
    exit(0);
}