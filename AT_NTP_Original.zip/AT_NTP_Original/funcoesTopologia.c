#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <omp.h>
#include "data_structures.h"
#include "funcoesLeitura.h"
#include "funcoesMatematicas.h"
#include "funcoesTopologia.h"
//Rotina para verificar se um valor existe em um vetor
BOOL existeNoVetor(int *vetor, int tamanhoVetor, int valor){
    int i;
    for(i = 0; i < tamanhoVetor; i++){
        if(vetor[i]==valor){
            return True;
        }
    }
    return False;
}
//Rotina para verificar se um vetor existe em outro (independente da ordem dos elementos)
BOOL existeNoConjunto(int *vetor1, int *vetor2, int tamanhoVetor1, int tamanhoVetor2){
    int i, j, contador;
    BOOL valorExistente;
    for(i = 0; i < tamanhoVetor1; i++){
        valorExistente = existeNoVetor(vetor2, tamanhoVetor2, vetor1[i]);
        if(!valorExistente){
            return False;
        }
    }
    return True;
}
//Rotina para retornar o ID da barra com o menor número
int retornaIDmenorBarra(DBAR *dadosBarra, int *IDbarras, int numeroBarrasCaminho){
    int i, IDmenorBarra, menorNumero;
    IDmenorBarra = IDbarras[0];
    menorNumero = dadosBarra[IDmenorBarra].numeroBarra;
    for(i=1; i<numeroBarrasCaminho; i++){
        if(dadosBarra[IDbarras[i]].numeroBarra<menorNumero){
            IDmenorBarra = IDbarras[i];
            menorNumero = dadosBarra[IDmenorBarra].numeroBarra;
        }
    }
    return IDmenorBarra;
}
//Rotina para listar os caminhos de fatoração em uma subestação
void listaCaminhosFatoracaoSubestacao(DSUBESTACAO *dadosSubestacao, int IDsubestacao){
    int i, j, contadorCaminhos=0, contadorBarras, tamanhoCaminhoTemporario, proximoNo, noAtual;
    BOOL fimProcura, noJuncao;
    for(contadorBarras=0; contadorBarras<dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes; contadorBarras++){
        tamanhoCaminhoTemporario = 0;
        noAtual = contadorBarras;
        if(contadorBarras==0){
            fimProcura = False;
            dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[0].IDbarras[0] = dadosSubestacao[IDsubestacao].IDbarrasRelevantes[contadorBarras];
            tamanhoCaminhoTemporario++;
            while(!fimProcura){
                proximoNo = dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[noAtual];
                if(proximoNo!=-1){
                    dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].IDbarras[tamanhoCaminhoTemporario] = dadosSubestacao[IDsubestacao].IDbarrasRelevantes[proximoNo];
                    tamanhoCaminhoTemporario++;
                    noAtual = proximoNo;
                }
                else{
                    fimProcura = True;
                }
            }
            dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].tamanho = tamanhoCaminhoTemporario;
            //Printar o caminho
            /*printf("Caminho %d: ", contadorCaminhos);
            for(i=0; i<tamanhoCaminhoTemporario; i++){
                printf("%d ", dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].IDbarras[i]);
            }
            printf("\n");*/
            contadorCaminhos++;
        }
        else{
            fimProcura = False;
            noJuncao = False;
            while(!fimProcura && !noJuncao){
                dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].IDbarras[tamanhoCaminhoTemporario] = dadosSubestacao[IDsubestacao].IDbarrasRelevantes[noAtual];
                tamanhoCaminhoTemporario++;
                for(i=0; i<contadorCaminhos; i++){
                    noJuncao = existeNoVetor(dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].IDbarras, dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].tamanho, dadosSubestacao[IDsubestacao].IDbarrasRelevantes[noAtual]);
                    //Verifica se foi encontrado um nó de junção entre dois caminhos
                    if(noJuncao){
                        if(tamanhoCaminhoTemporario>1){
                            for(j=0; j<(tamanhoCaminhoTemporario-1); j++){
                                dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].IDbarras[j+ dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].tamanho] = dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].IDbarras[j];
                            }
                            dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].tamanho =  dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].tamanho + tamanhoCaminhoTemporario - 1;
                        }
                        break;
                    }
                }
                if(!noJuncao){
                    noAtual = dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[noAtual];
                    if(noAtual==-1){
                        fimProcura = True;
                    }
                }
            }
            if(!noJuncao){
                dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorCaminhos].tamanho = tamanhoCaminhoTemporario;
                contadorCaminhos++;
            }
        }
    }
    dadosSubestacao[IDsubestacao].quantidadeBarrasAssociadas = contadorCaminhos;
    return;
}
//Rotina para listar 
int listaCaminhosEVerificaIlhaEnergizada(DBAR *dadosBarra, CAMINHO *caminhoFatoracao, LINHA *barrasAssociadas){
    int i, j, quantidadeIlhas=0, contadorBarras, contadorCaminhos, tamanhoCaminhoTemporario, proximoNo, noAtual, barraProcessada;
    BOOL fimProcura, noJuncao;
    LISTA *auxBarra;
    auxBarra = barrasAssociadas[0].head;
    contadorBarras = 0;
    while(auxBarra != NULL){
        barraProcessada = auxBarra->IDcoluna;
        //printf("Barra processada: %d\n", dadosBarra[barraProcessada].numeroBarra);
        tamanhoCaminhoTemporario = 0;
        noAtual = barraProcessada;
        caminhoFatoracao[quantidadeIlhas].energizado = False;
        if(contadorBarras==0){
            fimProcura = False;
            caminhoFatoracao[0].IDbarras[0] = barraProcessada;
            if(dadosBarra[barraProcessada].energizada && dadosBarra[barraProcessada].quantidadeRamosAssociados>0){
                caminhoFatoracao[0].energizado = True;
            }
            tamanhoCaminhoTemporario++;
            dadosBarra[barraProcessada].IDcaminhoFatoracao = 0;
            while(!fimProcura){
                proximoNo = dadosBarra[noAtual].proximoNo;
                //printf("Proximo no: %d\n", proximoNo);
                if(proximoNo!=-1){
                    caminhoFatoracao[quantidadeIlhas].IDbarras[tamanhoCaminhoTemporario] = proximoNo;
                    if(dadosBarra[proximoNo].energizada && dadosBarra[proximoNo].quantidadeRamosAssociados>0){
                        caminhoFatoracao[quantidadeIlhas].energizado = True;
                    }
                    tamanhoCaminhoTemporario++;
                    dadosBarra[proximoNo].IDcaminhoFatoracao = quantidadeIlhas;
                    noAtual = proximoNo;
                }
                else{
                    fimProcura = True;
                }
            }
            caminhoFatoracao[quantidadeIlhas].tamanho = tamanhoCaminhoTemporario;
            quantidadeIlhas++;
        }
        else{
            fimProcura = False;
            noJuncao = False;
            while(!fimProcura && !noJuncao){
                caminhoFatoracao[quantidadeIlhas].IDbarras[tamanhoCaminhoTemporario] = noAtual;
                if(dadosBarra[noAtual].energizada && dadosBarra[noAtual].quantidadeRamosAssociados>0){
                    caminhoFatoracao[quantidadeIlhas].energizado = True;
                }
                tamanhoCaminhoTemporario++;
                for(contadorCaminhos=0; contadorCaminhos<quantidadeIlhas; contadorCaminhos++){
                    noJuncao = existeNoVetor(caminhoFatoracao[contadorCaminhos].IDbarras, caminhoFatoracao[contadorCaminhos].tamanho, noAtual);
                    if(noJuncao){
                        if(tamanhoCaminhoTemporario>1){
                            for(j=0; j<(tamanhoCaminhoTemporario-1); j++){
                                caminhoFatoracao[contadorCaminhos].IDbarras[j+ caminhoFatoracao[contadorCaminhos].tamanho] = caminhoFatoracao[quantidadeIlhas].IDbarras[j];
                                dadosBarra[caminhoFatoracao[quantidadeIlhas].IDbarras[j]].IDcaminhoFatoracao = contadorCaminhos;
                            }
                            caminhoFatoracao[contadorCaminhos].tamanho =  caminhoFatoracao[contadorCaminhos].tamanho + tamanhoCaminhoTemporario - 1;
                            if(caminhoFatoracao[quantidadeIlhas].energizado){
                                caminhoFatoracao[contadorCaminhos].energizado = True;
                            }
                        }
                        caminhoFatoracao[quantidadeIlhas].energizado = False;
                        break;
                    }
                }
                if(!noJuncao){
                    dadosBarra[noAtual].IDcaminhoFatoracao = quantidadeIlhas;
                    noAtual = dadosBarra[noAtual].proximoNo;
                    if(noAtual==-1){
                        fimProcura = True;
                    }
                    else{
                        if(noAtual == dadosBarra[noAtual].proximoNo){
                        printf("Erro: Barra %d associada a si mesma.\n", dadosBarra[noAtual].numeroBarra);
                        exit(1);
                        }
                        // printf("Proximo no: %d\n", dadosBarra[noAtual].numeroBarra);
                    }
                }
            }
            if(!noJuncao){
                caminhoFatoracao[quantidadeIlhas].tamanho = tamanhoCaminhoTemporario;
                quantidadeIlhas++;
            }
        }
        auxBarra = auxBarra->proximo;
        contadorBarras++;
    }
    return quantidadeIlhas;
}
//Rotida para completar os dados de barra
void completaDadosBarra(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, CAMINHO **caminhoFatoracao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes){
    int i, contadorBarras, contadorBarrasAdjacentes, contadorRamosAdjacentes, barraAdjacente, contadorRamos, contadorChaves, contadorGeradores, contadorCargas, contadorShunts, contadorArranjos, contadorSubestacoes;
    BOOL barraInexistente;
    (*caminhoFatoracao) = (CAMINHO *)malloc(numeroBarras*sizeof(CAMINHO));
    if((*caminhoFatoracao)==NULL){
        printf("Erro ao alocar memoria para caminhoFatoracao.\n");
        exit(1);
    }
    for(contadorBarras = 0; contadorBarras < numeroBarras; contadorBarras++){
        (*dadosBarra)[contadorBarras].energizada = False;
        (*caminhoFatoracao)[contadorBarras].IDbarras = (int *)malloc(numeroBarras*sizeof(int));
        if((*caminhoFatoracao)[contadorBarras].IDbarras==NULL){
            printf("Erro ao alocar memoria para IDbarras.\n");
            exit(1);
        }
        (*caminhoFatoracao)[contadorBarras].tamanho = 0;
        (*caminhoFatoracao)[contadorBarras].energizado = False;
        if((*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes>0){
            if(((*dadosBarra)[contadorBarras].IDramosAdjacentes = (int *)malloc((*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDramosAdjacentes.\n");
                exit(1);
            }
            if(((*dadosBarra)[contadorBarras].IDbarrasAdjacentes = (int *)malloc((*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDbarrasAdjacentes.\n");
                exit(1);
            }            
        }
        //Os ponteiros a seguir são alocados com tamanhos fixos para evitar alocação dinâmica
        if(((*dadosBarra)[contadorBarras].IDramosAssociados = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDramosAssociados.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDbarrasAdjacentesAssociadas = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDbarrasAdjacentesAssociadas.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDramosTracking = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDramosTracking.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDbarrasTracking = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDbarrasTracking.\n");
            exit(1);
        }
        contadorBarrasAdjacentes = 0;
        contadorRamosAdjacentes = 0;
        for(contadorRamos = 0; contadorRamos < numeroRamos; contadorRamos++){
            //printf("Ramo %d\n", contadorRamos);
            //printf("\n\n\nVIM ATE AQUI\n\n\n");
            if((*dadosRamo)[contadorRamos].IDbarraDe == (*dadosBarra)[contadorBarras].IDbarra || (*dadosRamo)[contadorRamos].IDbarraPara == (*dadosBarra)[contadorBarras].IDbarra){
                (*dadosBarra)[contadorBarras].IDramosAdjacentes[contadorRamosAdjacentes] = (*dadosRamo)[contadorRamos].IDramo;
                if((*dadosRamo)[contadorRamos].IDbarraDe == (*dadosBarra)[contadorBarras].IDbarra){
                    barraAdjacente = (*dadosRamo)[contadorRamos].IDbarraPara;
                }
                else{
                    barraAdjacente = (*dadosRamo)[contadorRamos].IDbarraDe;
                }
                contadorRamosAdjacentes++;
                barraInexistente = True; 
                for(i=0; i<contadorBarrasAdjacentes; i++){
                    if((*dadosBarra)[contadorBarras].IDbarrasAdjacentes[i] == barraAdjacente){
                        barraInexistente = False;
                        break;
                    }
                }
                if(barraInexistente){
                    (*dadosBarra)[contadorBarras].IDbarrasAdjacentes[contadorBarrasAdjacentes] = barraAdjacente;
                    contadorBarrasAdjacentes++;
                    (*dadosBarra)[contadorBarras].quantidadeBarrasAdjacentes++;
                }
            }
        }
        if((*dadosBarra)[contadorBarras].quantidadeChavesAdjacentes>0){
            if(((*dadosBarra)[contadorBarras].IDchavesAdjacentes = (int *)malloc((*dadosBarra)[contadorBarras].quantidadeChavesAdjacentes*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDchavesAdjacentes.\n");
                exit(1);
            }
        }
        contadorChaves = 0;
        for(i=0; i<numeroChaves; i++){
            if((*dadosChave)[i].IDbarraDe == (*dadosBarra)[contadorBarras].IDbarra || (*dadosChave)[i].IDbarraPara == (*dadosBarra)[contadorBarras].IDbarra){
                (*dadosBarra)[contadorBarras].IDchavesAdjacentes[contadorChaves] = (*dadosChave)[i].IDchave;
                contadorChaves++;
            }
        }
        if((*dadosBarra)[contadorBarras].quantidadeMedidores>0){
            if(((*dadosBarra)[contadorBarras].IDmedidores = (int *)malloc((*dadosBarra)[contadorBarras].quantidadeMedidores*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDmedidores.\n");
                exit(1);
            }
        }
        contadorArranjos = 0;
        for(i=0; i<numeroArranjos; i++){
            if((*dadosArranjo)[i].TP.IDbarra == (*dadosBarra)[contadorBarras].IDbarra || (*dadosArranjo)[i].TC.IDbarraDe == (*dadosBarra)[contadorBarras].IDbarra){
                (*dadosBarra)[contadorBarras].IDmedidores[contadorArranjos] = (*dadosArranjo)[i].IDarranjo;
                contadorArranjos++;
            }
        }
        //Os ponteiros a seguir são alocados com tamanhos fixos para evitar alocação dinâmica
        if(((*dadosBarra)[contadorBarras].IDgeradoresAssociados = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDgeradoresAssociados.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDcargasAssociadas = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDcargasAssociadas.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDshuntsAssociados = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDshuntsAssociados.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDmedidoresAssociados = (int *)malloc(30*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDmedidoresAssociados.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDgeradoresTracking = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDgeradoresTrackin.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDcargasTracking = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDcargasTracking.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDshuntsTracking = (int *)malloc(20*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDshuntsTracking.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].IDmedidoresTracking = (int *)malloc(30*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDmedidoresTracking.\n");
            exit(1);
        }
        if(((*dadosBarra)[contadorBarras].medidas = (DMED *)malloc(30*sizeof(DMED)))==NULL){
            printf("Erro ao alocar memoria para medidas.\n");
            exit(1);
        }
        (*dadosBarra)[contadorBarras].quantidadeMedidas = 0;
    }
}
//Rotina para completar os dados das subestações
void completaDadosSubestacao(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes){
    int aux, i, j, IDbarraIrrelevante, numeroBarraIrrelevante, contadorBarras, contadorBarrasRelevantes, contadorBarrasIrrelevantes, contadorBarrasAdjacentes, contadorRamosAdjacentes, barraAdjacente, contadorRamos, contadorChaves, contadorGeradores, contadorCargas, contadorShunts, contadorArranjos, contadorSubestacoes;
    for(contadorSubestacoes=0; contadorSubestacoes<numeroSubestacoes; contadorSubestacoes++){
        //Faz a separação de barras relevantes e irrelevantes para o PNS
        for(contadorBarras=0; contadorBarras<(*dadosSubestacao)[contadorSubestacoes].quantidadeBarras; contadorBarras++){
            if((*dadosBarra)[(*dadosSubestacao)[contadorSubestacoes].IDbarras[contadorBarras]].quantidadeChavesAdjacentes==0){
                (*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasIrrelevantes++;
            }
            else{
                (*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes++;
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDbarrasRelevantes = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDbarrasRelevantes.\n");
                exit(1);
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasIrrelevantes>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDbarrasIrrelevantes = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasIrrelevantes*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDbarrasIrrelevantes.\n");
                exit(1);
            }
        }
        contadorBarrasRelevantes = 0;
        contadorBarrasIrrelevantes = 0;
        for(contadorBarras=0; contadorBarras<(*dadosSubestacao)[contadorSubestacoes].quantidadeBarras; contadorBarras++){
            if((*dadosBarra)[(*dadosSubestacao)[contadorSubestacoes].IDbarras[contadorBarras]].quantidadeChavesAdjacentes==0){
                (*dadosSubestacao)[contadorSubestacoes].IDbarrasIrrelevantes[contadorBarrasIrrelevantes] = (*dadosSubestacao)[contadorSubestacoes].IDbarras[contadorBarras];
                IDbarraIrrelevante = (*dadosSubestacao)[contadorSubestacoes].IDbarras[contadorBarras];
                numeroBarraIrrelevante = (*dadosBarra)[IDbarraIrrelevante].numeroBarra;
                contadorBarrasIrrelevantes++;
                //Se a barra for irrelevante, o conjunto de componentes associadas a ela não vai mudar,
                //mesmo durante a execução do configurador tracking
                if((*dadosBarra)[IDbarraIrrelevante].IDgerador!=-1){
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeGeradoresAssociados = 1;
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeGeradoresTracking = 1;
                    (*dadosBarra)[IDbarraIrrelevante].IDgeradoresAssociados = (*dadosBarra)[IDbarraIrrelevante].IDgerador;
                    (*dadosBarra)[IDbarraIrrelevante].IDgeradoresTracking = (*dadosBarra)[IDbarraIrrelevante].IDgerador;
                    (*dadosGerador)[(*dadosBarra)[IDbarraIrrelevante].IDgerador].IDbarraAssociada = IDbarraIrrelevante;
                    (*dadosGerador)[(*dadosBarra)[IDbarraIrrelevante].IDgerador].barraAssociada = numeroBarraIrrelevante;
                }
                if((*dadosBarra)[IDbarraIrrelevante].IDcarga!=-1){
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeCargasAssociadas = 1;
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeCargasTracking = 1;
                    (*dadosBarra)[IDbarraIrrelevante].IDcargasAssociadas = (*dadosBarra)[IDbarraIrrelevante].IDcarga;
                    (*dadosBarra)[IDbarraIrrelevante].IDcargasTracking = (*dadosBarra)[IDbarraIrrelevante].IDcarga;
                    (*dadosCarga)[(*dadosBarra)[IDbarraIrrelevante].IDcarga].IDbarraAssociada = IDbarraIrrelevante;
                    (*dadosCarga)[(*dadosBarra)[IDbarraIrrelevante].IDcarga].barraAssociada = numeroBarraIrrelevante;
                }
                if((*dadosBarra)[IDbarraIrrelevante].IDshunt!=-1){
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeShuntsAssociados = 1;
                    (*dadosBarra)[IDbarraIrrelevante].quantidadeShuntsTracking = 1;
                    (*dadosBarra)[IDbarraIrrelevante].IDshuntsAssociados = (*dadosBarra)[IDbarraIrrelevante].IDshunt;
                    (*dadosBarra)[IDbarraIrrelevante].IDshuntsTracking = (*dadosBarra)[IDbarraIrrelevante].IDshunt;
                    (*dadosShunt)[(*dadosBarra)[IDbarraIrrelevante].IDshunt].IDbarraAssociada = IDbarraIrrelevante;
                    (*dadosShunt)[(*dadosBarra)[IDbarraIrrelevante].IDshunt].barraAssociada = numeroBarraIrrelevante;
                }
                for(i=0; i<(*dadosBarra)[IDbarraIrrelevante].quantidadeRamosAdjacentes; i++){
                    (*dadosBarra)[IDbarraIrrelevante].IDramosAssociados[i] = (*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i];
                    (*dadosBarra)[IDbarraIrrelevante].IDramosTracking[i] = (*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i];
                    if((*dadosRamo)[(*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i]].IDbarraDe == IDbarraIrrelevante){
                        (*dadosRamo)[(*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i]].IDbarraDeAssociada = IDbarraIrrelevante;
                        (*dadosRamo)[(*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i]].barraDeAssociada = numeroBarraIrrelevante;
                    }
                    else{
                        (*dadosRamo)[(*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i]].IDbarraParaAssociada = IDbarraIrrelevante;
                        (*dadosRamo)[(*dadosBarra)[IDbarraIrrelevante].IDramosAdjacentes[i]].barraParaAssociada = numeroBarraIrrelevante;
                    }
                }
                (*dadosBarra)[IDbarraIrrelevante].quantidadeRamosAssociados = (*dadosBarra)[IDbarraIrrelevante].quantidadeRamosAdjacentes;
                (*dadosBarra)[IDbarraIrrelevante].quantidadeRamosTracking = (*dadosBarra)[IDbarraIrrelevante].quantidadeRamosAdjacentes;
                //printf("\nNumero de ramos adjacentes a barra irrelevante: %d\n",(*dadosBarra)[IDbarraIrrelevante].quantidadeRamosAssociados);
                for(i=0; i<(*dadosBarra)[IDbarraIrrelevante].quantidadeMedidores; i++){
                    (*dadosBarra)[IDbarraIrrelevante].IDmedidoresAssociados[i] = (*dadosBarra)[IDbarraIrrelevante].IDmedidores[i];
                    (*dadosBarra)[IDbarraIrrelevante].IDmedidoresTracking[i] = (*dadosBarra)[IDbarraIrrelevante].IDmedidores[i];
                    if((*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TP.IDbarra == IDbarraIrrelevante){
                        (*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TP.IDbarraAssociada = IDbarraIrrelevante;
                        (*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TP.barraAssociada = numeroBarraIrrelevante;
                    }
                    if((*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TC.IDbarraDe == IDbarraIrrelevante){
                        (*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TC.IDbarraDeAssociada = IDbarraIrrelevante;
                        (*dadosArranjo)[(*dadosBarra)[IDbarraIrrelevante].IDmedidores[i]].TC.barraDeAssociada = numeroBarraIrrelevante;
                    }
                }
                (*dadosBarra)[IDbarraIrrelevante].quantidadeMedidoresAssociados = (*dadosBarra)[IDbarraIrrelevante].quantidadeMedidores;
                (*dadosBarra)[IDbarraIrrelevante].quantidadeMedidoresTracking = (*dadosBarra)[IDbarraIrrelevante].quantidadeMedidores;
                (*dadosBarra)[IDbarraIrrelevante].numeroBarraAssociada = numeroBarraIrrelevante;
                (*dadosBarra)[IDbarraIrrelevante].IDbarraAssociada = IDbarraIrrelevante;
            }
            else{
                (*dadosSubestacao)[contadorSubestacoes].IDbarrasRelevantes[contadorBarrasRelevantes] = (*dadosSubestacao)[contadorSubestacoes].IDbarras[contadorBarras];
                contadorBarrasRelevantes++;
            }
        }
        if(((*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.no = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para arvoreFatoracao.no.\n");
            exit(1);
        }
        if(((*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.proximoNo = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para arvoreFatoracao.proximoNo.\n");
            exit(1);
        }
        (*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.tamanho = (*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes;
        for(aux=0; aux<(*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.tamanho; aux++){
            (*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.no[aux] = aux;
            (*dadosSubestacao)[contadorSubestacoes].arvoreFatoracao.proximoNo[aux] = -1;
        }
        if(((*dadosSubestacao)[contadorSubestacoes].IDbarrasAssociadas = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarras*sizeof(int)))==NULL){
            printf("Erro ao alocar memoria para IDbarrasAssociadas.\n");
            exit(1);
        }
        if(((*dadosSubestacao)[contadorSubestacoes].listaCaminhosFatoracao = (CAMINHO *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarras*sizeof(CAMINHO)))==NULL){
            printf("Erro ao alocar memoria para listaCaminhosFatoracao.\n");
            exit(1);
        }
        for(i=0; i<(*dadosSubestacao)[contadorSubestacoes].quantidadeBarras; i++){
            (*dadosSubestacao)[contadorSubestacoes].listaCaminhosFatoracao[i].IDbarras = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeBarras*sizeof(int));
            if((*dadosSubestacao)[contadorSubestacoes].listaCaminhosFatoracao[i].IDbarras == NULL){
                printf("Erro ao alocar memoria para listaCaminhosFatoracao.IDbarras.\n");
                exit(1);
            }
            (*dadosSubestacao)[contadorSubestacoes].listaCaminhosFatoracao[i].tamanho = 0;
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeChaves>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDchaves = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeChaves*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDchaves.\n");
                exit(1);
            }
            if(((*dadosSubestacao)[contadorSubestacoes].IDchavesReferencia = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeChaves*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDchavesReferencia.\n");
                exit(1);
            }
        }
        contadorChaves = 0;
        for(i=0; i<numeroChaves; i++){
            if((*dadosChave)[i].IDsubestacao == (*dadosSubestacao)[contadorSubestacoes].IDsubestacao){
                (*dadosSubestacao)[contadorSubestacoes].IDchaves[contadorChaves] = (*dadosChave)[i].IDchave;
                (*dadosSubestacao)[contadorSubestacoes].IDchavesReferencia[contadorChaves] = (*dadosChave)[i].IDchave;
                contadorChaves++;
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeGeradores>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDgeradores = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeGeradores*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDgeradores.\n");
                exit(1);
            }
        }
        contadorGeradores = 0;
        for(i=0; i<numeroGeradores; i++){
            if((*dadosGerador)[i].IDsubestacao == (*dadosSubestacao)[contadorSubestacoes].IDsubestacao){
                (*dadosSubestacao)[contadorSubestacoes].IDgeradores[contadorGeradores] = (*dadosGerador)[i].IDgerador;
                contadorGeradores++;
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeCargas>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDcargas = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeCargas*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDcargas.\n");
                exit(1);
            }
        }
        contadorCargas = 0;
        for(i=0; i<numeroCargas; i++){
            if((*dadosCarga)[i].IDsubestacao == (*dadosSubestacao)[contadorSubestacoes].IDsubestacao){
                (*dadosSubestacao)[contadorSubestacoes].IDcargas[contadorCargas] = (*dadosCarga)[i].IDcarga;
                contadorCargas++;
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeShunts>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDshunts = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeShunts*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDshunts.\n");
                exit(1);
            }
        }
        contadorShunts = 0;
        for(i=0; i<numeroShunts; i++){
            if((*dadosShunt)[i].IDsubestacao == (*dadosSubestacao)[contadorSubestacoes].IDsubestacao){
                (*dadosSubestacao)[contadorSubestacoes].IDshunts[contadorShunts] = (*dadosShunt)[i].IDshunt;
                contadorShunts++;
            }
        }
        if((*dadosSubestacao)[contadorSubestacoes].quantidadeMedidores>0){
            if(((*dadosSubestacao)[contadorSubestacoes].IDmedidores = (int *)malloc((*dadosSubestacao)[contadorSubestacoes].quantidadeMedidores*sizeof(int)))==NULL){
                printf("Erro ao alocar memoria para IDarranjos.\n");
                exit(1);
            }
        }
        contadorArranjos = 0;
        for(i=0; i<numeroArranjos; i++){
            if((*dadosArranjo)[i].IDsubestacao == (*dadosSubestacao)[contadorSubestacoes].IDsubestacao){
                (*dadosSubestacao)[contadorSubestacoes].IDmedidores[contadorArranjos] = (*dadosArranjo)[i].IDarranjo;
                contadorArranjos++;
            }
        }
        //Inicializa as matrizes Href, Hf e de fatores
        criaMatrizIdentidade(&(*dadosSubestacao)[contadorSubestacoes].fatores,(*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes);
        inicializaMatriz(&(*dadosSubestacao)[contadorSubestacoes].Href, (*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes);
        inicializaMatriz(&(*dadosSubestacao)[contadorSubestacoes].Hf, (*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes);
        for(i=0; i<(*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes; i++){
            for(j=0; j<(*dadosSubestacao)[contadorSubestacoes].quantidadeChaves; j++){
                if((*dadosChave)[(*dadosSubestacao)[contadorSubestacoes].IDchaves[j]].IDbarraDe == (*dadosSubestacao)[contadorSubestacoes].IDbarrasRelevantes[i]){
                    alteraValor(&(*dadosSubestacao)[contadorSubestacoes].Href, i, j, 1);
                }
                else if((*dadosChave)[(*dadosSubestacao)[contadorSubestacoes].IDchaves[j]].IDbarraPara == (*dadosSubestacao)[contadorSubestacoes].IDbarrasRelevantes[i]){
                    alteraValor(&(*dadosSubestacao)[contadorSubestacoes].Href, i, j, -1);
                }
            }
        }
        igualaMatrizes(&(*dadosSubestacao)[contadorSubestacoes].Hf, (*dadosSubestacao)[contadorSubestacoes].Href,(*dadosSubestacao)[contadorSubestacoes].quantidadeBarrasRelevantes, (*dadosSubestacao)[contadorSubestacoes].quantidadeChaves);

    }
}
//Rotina para completar os dados da rede que não foram preenchidos durante a leitura dos 
//dados de entrada.
void completaDadosRede(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                            DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, CAMINHO **caminhoFatoracao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes){
    completaDadosBarra(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, caminhoFatoracao, numeroBarras,
                            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes);
    completaDadosSubestacao(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, numeroBarras,
                            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes);
    return;
}
//Rotina para a associação de barras por subestação
void associaBarrasPorSubestacao(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int IDsubestacao){
    int i, contadorBarrasAssociadas, contadorBarrasCaminho, IDbarraAssociada, numeroBarrasAssociada, IDbarraCaminho;
    int quantidadeRamosAssociados, quantidadeGeradoresAssociados, quantidadeCargasAssociadas, quantidadeShuntsAssociados, quantidadeMedidoresAssociados;
    BOOL existe;
    for(contadorBarrasAssociadas=0; contadorBarrasAssociadas<dadosSubestacao[IDsubestacao].quantidadeBarrasAssociadas; contadorBarrasAssociadas++){
        IDbarraAssociada = retornaIDmenorBarra(dadosBarra, dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].IDbarras,dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].tamanho);
        numeroBarrasAssociada = dadosBarra[IDbarraAssociada].numeroBarra;
        dadosSubestacao[IDsubestacao].IDbarrasAssociadas[contadorBarrasAssociadas] = IDbarraAssociada;
        quantidadeRamosAssociados = 0;
        quantidadeGeradoresAssociados = 0;
        quantidadeCargasAssociadas = 0;
        quantidadeShuntsAssociados = 0; 
        quantidadeMedidoresAssociados = 0;
        for(contadorBarrasCaminho=0; contadorBarrasCaminho<dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].tamanho; contadorBarrasCaminho++){
            IDbarraCaminho = dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].IDbarras[contadorBarrasCaminho];
            dadosBarra[IDbarraCaminho].numeroBarraAssociada = numeroBarrasAssociada;
            dadosBarra[IDbarraCaminho].IDbarraAssociada = IDbarraAssociada;
            for(i=0; i<dadosBarra[IDbarraCaminho].quantidadeRamosAdjacentes; i++){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDramosAssociados,quantidadeRamosAssociados,dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]);
                if(!existe){
                    dadosBarra[IDbarraAssociada].IDramosAssociados[quantidadeRamosAssociados] = dadosBarra[IDbarraCaminho].IDramosAdjacentes[i];
                    if(dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDe == IDbarraCaminho){
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDeAssociada = IDbarraAssociada;
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].barraDeAssociada = numeroBarrasAssociada;
                    }
                    else{
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraParaAssociada = IDbarraAssociada;
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].barraParaAssociada = numeroBarrasAssociada;
                    }
                    quantidadeRamosAssociados++;
                }
            }
            if(dadosBarra[IDbarraCaminho].IDgerador!=-1){
                dadosBarra[IDbarraAssociada].IDgeradoresAssociados[quantidadeGeradoresAssociados] = dadosBarra[IDbarraCaminho].IDgerador;
                dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].IDbarraAssociada = IDbarraAssociada;
                dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].barraAssociada = numeroBarrasAssociada;
                if(dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].ligado==1){
                    dadosBarra[IDbarraAssociada].energizada = True;
                }
                quantidadeGeradoresAssociados++;
            }
            if(dadosBarra[IDbarraCaminho].IDcarga!=-1){
                dadosBarra[IDbarraAssociada].IDcargasAssociadas[quantidadeCargasAssociadas] = dadosBarra[IDbarraCaminho].IDcarga;
                dadosCarga[dadosBarra[IDbarraCaminho].IDcarga].IDbarraAssociada = IDbarraAssociada;
                dadosCarga[dadosBarra[IDbarraCaminho].IDcarga].barraAssociada = numeroBarrasAssociada;
                quantidadeCargasAssociadas++;
            } 
            if(dadosBarra[IDbarraCaminho].IDshunt!=-1){
                dadosBarra[IDbarraAssociada].IDshuntsAssociados[quantidadeShuntsAssociados] = dadosBarra[IDbarraCaminho].IDshunt;
                dadosShunt[dadosBarra[IDbarraCaminho].IDshunt].IDbarraAssociada = IDbarraAssociada;
                dadosShunt[dadosBarra[IDbarraCaminho].IDshunt].barraAssociada = numeroBarrasAssociada;
                quantidadeShuntsAssociados++;
            }
            for(i=0; i<dadosBarra[IDbarraCaminho].quantidadeMedidores; i++){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDmedidoresAssociados, quantidadeMedidoresAssociados, dadosBarra[IDbarraCaminho].IDmedidores[i]);
                if(!existe){
                    dadosBarra[IDbarraAssociada].IDmedidoresAssociados[quantidadeMedidoresAssociados] = dadosBarra[IDbarraCaminho].IDmedidores[i];
                    //Medição de potência
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==0){
                        if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarra==IDbarraCaminho){
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarraAssociada = IDbarraAssociada;
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.barraAssociada = numeroBarrasAssociada;
                        }
                        if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDe==IDbarraCaminho){
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDeAssociada = IDbarraAssociada;
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.barraDeAssociada = numeroBarrasAssociada;
                        }
                    }
                    //Medição de tensão
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==1){
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarraAssociada = IDbarraAssociada;
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.barraAssociada = numeroBarrasAssociada;
                    }
                    //edição de corrente
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==2){
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDeAssociada = IDbarraAssociada;
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.barraDeAssociada = numeroBarrasAssociada;
                    }
                    quantidadeMedidoresAssociados++;
                }
            }
        }
        dadosBarra[IDbarraAssociada].quantidadeRamosAssociados = quantidadeRamosAssociados;
        dadosBarra[IDbarraAssociada].quantidadeGeradoresAssociados = quantidadeGeradoresAssociados;
        dadosBarra[IDbarraAssociada].quantidadeCargasAssociadas = quantidadeCargasAssociadas;
        dadosBarra[IDbarraAssociada].quantidadeShuntsAssociados = quantidadeShuntsAssociados;
        dadosBarra[IDbarraAssociada].quantidadeMedidoresAssociados = quantidadeMedidoresAssociados;
    }
    return;
}
//Rotina do Procesamento em Nível de Subestação
void PNS(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, int numeroBarras,
                            int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes){
    int contadorSubestacoes, contadorChaves, sucesso;
    //Fatoração das matrizes de incidência e identificação dos caminhos
    //de fatoração de cada subestação
    for(contadorSubestacoes=0; contadorSubestacoes<numeroSubestacoes; contadorSubestacoes++){
        //Zerar colunas da matriz Hf referentes às chaves que estão abertas
        for(contadorChaves=0; contadorChaves<dadosSubestacao[contadorSubestacoes].quantidadeChaves; contadorChaves++){
            if(dadosChave[dadosSubestacao[contadorSubestacoes].IDchavesReferencia[contadorChaves]].status == 0){
                zeraColuna(&dadosSubestacao[contadorSubestacoes].Hf, dadosSubestacao[contadorSubestacoes].quantidadeBarrasRelevantes, contadorChaves);
            }
        }
        //Fatoração da matriz de incidência
        sucesso = fatoraMatrizAssimetrica(&dadosSubestacao[contadorSubestacoes].Hf,&dadosSubestacao[contadorSubestacoes].fatores,dadosSubestacao[contadorSubestacoes].quantidadeBarrasRelevantes,&dadosSubestacao[contadorSubestacoes].arvoreFatoracao);
        if(sucesso == 1){
            printf("\n\n\nErro ao fatorar a matriz de incidencia da subestaçao %d.\n\n\n", dadosSubestacao[contadorSubestacoes].IDsubestacao);
            exit(1);
        }
        /*else{
            printf("\n\n\nMatriz de incidencia da subestaçao %d fatorada com sucesso.\n\n\n", dadosSubestacao[contadorSubestacoes].IDsubestacao);
            //exit(1);
        }*/
        //Identifica os caminhos de fatoração
        listaCaminhosFatoracaoSubestacao(dadosSubestacao, contadorSubestacoes);
        //Associação das barras por subestação
        associaBarrasPorSubestacao(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, numeroBarras,
                            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes, contadorSubestacoes);
    }
    return;
}
//Rotina para preencher a matriz de admitância primitiva/Adjacência
void constroiMatrizY(DBAR *dadosBarra, DRAM *dadosRamo, LINHA **matrizY, LINHA **barrasAssociadas, int numeroBarras){
    int contadorBarras, contadorAdjacentes;
    double valor;
    for(contadorBarras=0; contadorBarras<numeroBarras; contadorBarras++){
        //Se o ID da barra for diferente do ID associado, então a seção de barramento
        //correspondente não será utilizada durante a fatoração
        if(dadosBarra[contadorBarras].IDbarra==dadosBarra[contadorBarras].IDbarraAssociada){
            alteraValor(barrasAssociadas,0,contadorBarras,1);
            alteraValor(matrizY, contadorBarras, contadorBarras, dadosBarra[contadorBarras].quantidadeRamosAssociados);
            for(contadorAdjacentes=0; contadorAdjacentes<dadosBarra[contadorBarras].quantidadeRamosAssociados; contadorAdjacentes++){
                if(dadosRamo[dadosBarra[contadorBarras].IDramosAssociados[contadorAdjacentes]].IDbarraDeAssociada==contadorBarras){
                    valor = consultaValor(*matrizY, contadorBarras, dadosRamo[dadosBarra[contadorBarras].IDramosAssociados[contadorAdjacentes]].IDbarraParaAssociada);
                    valor = valor - 1;
                    alteraValor(matrizY, contadorBarras, dadosRamo[dadosBarra[contadorBarras].IDramosAssociados[contadorAdjacentes]].IDbarraParaAssociada, valor);
                }
                else{
                    valor = consultaValor(*matrizY, contadorBarras, dadosRamo[dadosBarra[contadorBarras].IDramosAssociados[contadorAdjacentes]].IDbarraDeAssociada);
                    valor = valor - 1;
                    alteraValor(matrizY, contadorBarras, dadosRamo[dadosBarra[contadorBarras].IDramosAssociados[contadorAdjacentes]].IDbarraDeAssociada, valor);
                }
            }
        }
    }
    return;
}
//Rotina do Processamento em Nível de Rede
LINHA *PNR(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas){
    LINHA *barrasAssociadas;
    barrasAssociadas = (LINHA *) malloc(sizeof(LINHA));
    if(barrasAssociadas == NULL){
        printf("\n\n\nErro ao alocar memória para as barras associadas.\n\n\n");
        exit(1);
    }
    barrasAssociadas[0].IDlinha = 0;
    barrasAssociadas[0].tamanho = 0;
    barrasAssociadas[0].head = NULL;
    int sucesso;
    inicializaMatriz(matrizY, numeroBarras);
    criaMatrizIdentidade(fatoresY, numeroBarras);
    constroiMatrizY(dadosBarra, dadosRamo, matrizY, &barrasAssociadas, numeroBarras);
    //imprimeMatriz(barrasAssociadas, numeroBarras);
    //printf("\n%d\n",barrasAssociadas[0].tamanho);
    sucesso = fatoraMatrizSimetrica(matrizY, fatoresY, &barrasAssociadas, dadosBarra);
    if(sucesso == 1){
        printf("\n\n\nErro ao fatorar a matriz de incidencia.\n\n\n");
        exit(1);
    }
    numeroIlhas[0] = listaCaminhosEVerificaIlhaEnergizada(dadosBarra, caminhosFatoracao, barrasAssociadas);

    //imprimeMatriz(*matrizY, numeroBarras);
    return barrasAssociadas;
}
//Rotina para processar os dados de medição
void processaMedicao(DBAR *dadosBarra, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt,  DARRANJO *dadosArranjo, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao){
    int contador, barraAtual, ilhaAtual, contadorArranjos, IDmedidor, contadorMedidas, IDshunt;
    BOOL excluiMedicao, injecaoPotenciaHabilitada, injecaoCorrenteHabilitada;
    LISTA *auxBarra;
    auxBarra = barrasAssociadas[0].head;
    //printf("\n%d\n",barrasAssociadas[0].tamanho);
    while(auxBarra!=NULL){
        //printf("\nVerificando energizacao");
        barraAtual = auxBarra->IDcoluna;
        ilhaAtual = dadosBarra[barraAtual].IDcaminhoFatoracao;
        //Processa dados de medição apenas para as ilhas energizadas
        if(caminhosFatoracao[ilhaAtual].energizado){
            contadorMedidas = 0;
            injecaoPotenciaHabilitada = True;
            injecaoCorrenteHabilitada = True;
            for(contador=0; contador<dadosBarra[barraAtual].quantidadeMedidoresAssociados; contador++){
                excluiMedicao = False;
                IDmedidor = dadosBarra[barraAtual].IDmedidoresAssociados[contador];
                //Print tipo do medidor
                //Medida de potência
                if(dadosArranjo[IDmedidor].tipoMedidor==0){
                    if(dadosArranjo[IDmedidor].TC.IDbarraPara!=-1){
                        dadosArranjo[IDmedidor].TC.IDbarraParaAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraPara].IDbarraAssociada;
                        dadosArranjo[IDmedidor].TC.barraParaAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraPara].numeroBarraAssociada;
                    }
                    dadosArranjo[IDmedidor].TP.IDbarraAssociada = dadosBarra[dadosArranjo[IDmedidor].TP.IDbarra].IDbarraAssociada;
                    dadosArranjo[IDmedidor].TP.barraAssociada = dadosBarra[dadosArranjo[IDmedidor].TP.IDbarra].numeroBarraAssociada;
                    dadosArranjo[IDmedidor].TC.IDbarraDeAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraDe].IDbarraAssociada;
                    dadosArranjo[IDmedidor].TC.barraDeAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraDe].numeroBarraAssociada;
                    if(dadosArranjo[IDmedidor].IDbarraLTR!=-1){
                        dadosArranjo[IDmedidor].IDbarraLTRAssociada = dadosBarra[dadosArranjo[IDmedidor].IDbarraLTR].IDbarraAssociada;
                        dadosArranjo[IDmedidor].barraLTRAssociada = dadosBarra[dadosArranjo[IDmedidor].IDbarraLTR].numeroBarraAssociada;
                    }
                    //printf("\n%d, %d, %d\n",dadosArranjo[IDmedidor].TP.barra,dadosArranjo[IDmedidor].TC.barraDeAssociada, dadosArranjo[IDmedidor].TC.barraParaAssociada);
                    if(dadosArranjo[IDmedidor].TP.IDbarraAssociada!=dadosArranjo[IDmedidor].TC.IDbarraDeAssociada){
                        excluiMedicao = True;
                    }
                    if((dadosArranjo[IDmedidor].TC.IDbarraDeAssociada!=dadosArranjo[IDmedidor].TC.IDbarraParaAssociada) && (dadosArranjo[IDmedidor].TC.IDbarraParaAssociada!=-1)){
                        excluiMedicao = True;
                    }
                    if(!excluiMedicao){
                        if((dadosArranjo[IDmedidor].tipoEquipamento==0) || (dadosArranjo[IDmedidor].tipoEquipamento==1)){
                            dadosBarra[barraAtual].medidas[contadorMedidas].tipo = 0;
                            dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraDe = barraAtual;
                            dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara = dadosArranjo[IDmedidor].IDbarraLTRAssociada;
                            contadorMedidas++;
                        }
                        else{
                            IDshunt = dadosArranjo[IDmedidor].IDshunt;
                            if(dadosArranjo[IDmedidor].tipoEquipamento==2){
                                dadosCarga[IDshunt].possuiMedidaPotencia = True;
                            }
                            if(dadosArranjo[IDmedidor].tipoEquipamento==3){
                                dadosShunt[IDshunt].possuiMedidaPotencia = True;
                            }
                            else if(dadosArranjo[IDmedidor].tipoEquipamento==4){
                                dadosGerador[IDshunt].possuiMedidaPotencia = True;
                            }
                        }
                    }
                    else{
                        IDshunt = dadosArranjo[IDmedidor].IDshunt;
                        if(dadosArranjo[IDmedidor].tipoEquipamento==2){
                            dadosCarga[IDshunt].possuiMedidaPotencia = False;
                        }
                        if(dadosArranjo[IDmedidor].tipoEquipamento==3){
                            dadosShunt[IDshunt].possuiMedidaPotencia = False;
                        }
                        else if(dadosArranjo[IDmedidor].tipoEquipamento==4){
                            dadosGerador[IDshunt].possuiMedidaPotencia = False;
                        }
                    }
                }
                //Medida de corrente
                if(dadosArranjo[IDmedidor].tipoMedidor==2){
                    if(dadosArranjo[IDmedidor].TC.IDbarraPara!=-1){
                        dadosArranjo[IDmedidor].TC.IDbarraParaAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraPara].IDbarraAssociada;
                        dadosArranjo[IDmedidor].TC.barraParaAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraPara].numeroBarraAssociada;
                    }
                    dadosArranjo[IDmedidor].TC.IDbarraDeAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraDe].IDbarraAssociada;
                    dadosArranjo[IDmedidor].TC.barraDeAssociada = dadosBarra[dadosArranjo[IDmedidor].TC.IDbarraDe].numeroBarraAssociada;
                    if(dadosArranjo[IDmedidor].IDbarraLTR!=-1){
                        dadosArranjo[IDmedidor].IDbarraLTRAssociada = dadosBarra[dadosArranjo[IDmedidor].IDbarraLTR].IDbarraAssociada;
                        dadosArranjo[IDmedidor].barraLTRAssociada = dadosBarra[dadosArranjo[IDmedidor].IDbarraLTR].numeroBarraAssociada;
                    }
                    if((dadosArranjo[IDmedidor].TC.IDbarraDeAssociada!=dadosArranjo[IDmedidor].TC.IDbarraParaAssociada) && (dadosArranjo[IDmedidor].TC.IDbarraParaAssociada!=-1)){
                        excluiMedicao = True;
                    }
                    if(!excluiMedicao){
                        if((dadosArranjo[IDmedidor].tipoEquipamento==0) || (dadosArranjo[IDmedidor].tipoEquipamento==1)){
                            dadosBarra[barraAtual].medidas[contadorMedidas].tipo = 2;
                            dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraDe = barraAtual;
                            dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara = dadosArranjo[IDmedidor].IDbarraLTRAssociada;
                            contadorMedidas++;
                        }
                        else{
                            IDshunt = dadosArranjo[IDmedidor].IDshunt;
                            if(dadosArranjo[IDmedidor].tipoEquipamento==2){
                                dadosCarga[IDshunt].possuiMedidaCorrente = True;
                            }
                            if(dadosArranjo[IDmedidor].tipoEquipamento==3){
                                dadosShunt[IDshunt].possuiMedidaCorrente = True;
                            }
                            else if(dadosArranjo[IDmedidor].tipoEquipamento==4){
                                dadosGerador[IDshunt].possuiMedidaCorrente = True;
                            }
                        }
                    }
                    else{
                        IDshunt = dadosArranjo[IDmedidor].IDshunt;
                        if(dadosArranjo[IDmedidor].tipoEquipamento==2){
                            dadosCarga[IDshunt].possuiMedidaCorrente = False;
                        }
                        if(dadosArranjo[IDmedidor].tipoEquipamento==3){
                            dadosShunt[IDshunt].possuiMedidaCorrente = False;
                        }
                        else if(dadosArranjo[IDmedidor].tipoEquipamento==4){
                            dadosGerador[IDshunt].possuiMedidaCorrente = False;
                        }
                    }
                }
                //Medida de tensão
                if(dadosArranjo[IDmedidor].tipoMedidor==1){
                    dadosArranjo[IDmedidor].TP.IDbarraAssociada = dadosBarra[dadosArranjo[IDmedidor].TP.IDbarra].IDbarraAssociada;
                    dadosArranjo[IDmedidor].TP.barraAssociada = dadosBarra[dadosArranjo[IDmedidor].TP.IDbarra].numeroBarraAssociada;
                    dadosBarra[barraAtual].medidas[contadorMedidas].tipo = 4;
                    dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraDe = barraAtual;
                    dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara = -1;
                    contadorMedidas++;
                }
            }
            contador = 0;
            if((dadosBarra[barraAtual].quantidadeGeradoresAssociados+dadosBarra[barraAtual].quantidadeCargasAssociadas)==0){
                if(dadosBarra[barraAtual].quantidadeShuntsAssociados>0){
                    injecaoPotenciaHabilitada = False;
                    injecaoCorrenteHabilitada = False;
                    for(contador=0; contador<dadosBarra[barraAtual].quantidadeShuntsAssociados; contador++){
                        IDshunt = dadosBarra[barraAtual].IDshuntsAssociados[contador];
                        if(dadosShunt[IDshunt].possuiMedidaPotencia){
                            injecaoPotenciaHabilitada = True;
                            //break;
                        }
                        if(dadosShunt[IDshunt].possuiMedidaCorrente){
                            injecaoCorrenteHabilitada = True;
                            //break;
                        }
                    }
                }
                else{
                    injecaoPotenciaHabilitada = False;
                    injecaoCorrenteHabilitada = False;
                }
            }
            contador = 0;
            while(contador<(dadosBarra[barraAtual].quantidadeGeradoresAssociados+dadosBarra[barraAtual].quantidadeCargasAssociadas) && (injecaoPotenciaHabilitada || injecaoCorrenteHabilitada)){
                if(contador<dadosBarra[barraAtual].quantidadeGeradoresAssociados){
                    IDshunt = dadosBarra[barraAtual].IDgeradoresAssociados[contador];
                    if(!dadosGerador[IDshunt].possuiMedidaPotencia){
                        injecaoPotenciaHabilitada = False;
                    }
                    if(!dadosGerador[IDshunt].possuiMedidaCorrente){
                        injecaoCorrenteHabilitada = False;
                    }
                }
                else{
                    IDshunt = dadosBarra[barraAtual].IDcargasAssociadas[contador-dadosBarra[barraAtual].quantidadeGeradoresAssociados];
                    if(!dadosCarga[IDshunt].possuiMedidaPotencia){
                        injecaoPotenciaHabilitada = False;
                    }
                    if(!dadosCarga[IDshunt].possuiMedidaCorrente){
                        injecaoCorrenteHabilitada = False;
                    }
                }
                contador++;
            }
            if(injecaoPotenciaHabilitada){
                dadosBarra[barraAtual].medidas[contadorMedidas].tipo = 1;
                dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraDe = barraAtual;
                dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara = -1;
                contadorMedidas++;
            }
            else{
                for(contador=0; contador<dadosBarra[barraAtual].quantidadeShuntsAssociados; contador++){
                    IDshunt = dadosBarra[barraAtual].IDshuntsAssociados[contador];
                    dadosShunt[IDshunt].possuiMedidaPotencia = False;
                }
            }
            if(injecaoCorrenteHabilitada){
                dadosBarra[barraAtual].medidas[contadorMedidas].tipo = 3;
                dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraDe = barraAtual;
                dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara = -1;
                contadorMedidas++;
            }
            else{
                for(contador=0; contador<dadosBarra[barraAtual].quantidadeShuntsAssociados; contador++){
                    IDshunt = dadosBarra[barraAtual].IDshuntsAssociados[contador];
                    dadosShunt[IDshunt].possuiMedidaCorrente = False;
                }
            }
            dadosBarra[barraAtual].quantidadeMedidas = contadorMedidas;
            //printf("\nBarra %d: %d medidas.", dadosBarra[barraAtual].numeroBarra, dadosBarra[barraAtual].quantidadeMedidoresAssociados);
        }
        //printf("\n%d\t%d\t%d\t%d\t%d",auxBarra->IDcoluna,dadosBarra[auxBarra->IDcoluna].IDcaminhoFatoracao,caminhosFatoracao[dadosBarra[auxBarra->IDcoluna].IDcaminhoFatoracao].energizado,dadosBarra[auxBarra->IDcoluna].quantidadeMedidoresAssociados,dadosBarra[auxBarra->IDcoluna].quantidadeRamosAssociados);
        auxBarra = auxBarra->proximo;
        //printf("\nCheguei ate aqui");
    }
    return;
}
//Rotina principal do configurador de rede
LINHA *configuradorRede(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas){
    LINHA *barrasAssociadas;
    PNS(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
            dadosShunt, dadosArranjo, dadosSubestacao, numeroBarras,
            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
            numeroShunts, numeroArranjos, numeroSubestacoes);
    barrasAssociadas = PNR(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, matrizY, fatoresY, caminhosFatoracao,
                            numeroBarras, numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes, numeroIlhas);                  
    processaMedicao(dadosBarra, dadosRamo, dadosGerador, dadosCarga, dadosShunt, dadosArranjo, barrasAssociadas, caminhosFatoracao);
    return barrasAssociadas;
}

//-----------------------------------------------------------------------------------------
//Rotinas do Configurador Tracking
//-----------------------------------------------------------------------------------------
//Rotina para identificar quais subestações foram modificadas
LINHA *identificaSubestacoesModificadas(DCHAVE *dadosChave, int numeroChaves){
    int contador;
    LINHA *subestacoesModificadas;
    subestacoesModificadas = (LINHA *) malloc(sizeof(LINHA));
    if(subestacoesModificadas==NULL){
        printf("\nErro na alocação de memória para subestacoesModificadas.\n");
        exit(1);
    }
    subestacoesModificadas[0].tamanho = 0;
    subestacoesModificadas[0].head = NULL;
    for(contador=0; contador<numeroChaves; contador++){
        if(dadosChave[contador].status != dadosChave[contador].statusAtualizado){
            alteraValor(&subestacoesModificadas, 0, dadosChave[contador].IDsubestacao,1);
            //printf("\nSubestacao %d modificada.", dadosChave[contador].IDsubestacao);
            //printf("\nChave modificada: %d\n", dadosChave[contador].IDchave);
        }
    }
    return subestacoesModificadas;
}
//Rotina para a associação de barras por subestação no configurador tracking
void associaBarrasPorSubestacaoTracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **barrasAfetadas, LINHA **ramosAfetados,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int IDsubestacao){
    int i, contadorBarrasAssociadas, contadorBarrasCaminho, IDbarraAssociada, numeroBarrasAssociada, IDbarraCaminho;
    int quantidadeRamosAssociados, quantidadeGeradoresAssociados, quantidadeCargasAssociadas, quantidadeShuntsAssociados, quantidadeMedidoresAssociados;
    BOOL existe;
    for(contadorBarrasAssociadas=0; contadorBarrasAssociadas<dadosSubestacao[IDsubestacao].quantidadeBarrasAssociadas; contadorBarrasAssociadas++){
        IDbarraAssociada = retornaIDmenorBarra(dadosBarra, dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].IDbarras,dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].tamanho);
        numeroBarrasAssociada = dadosBarra[IDbarraAssociada].numeroBarra;
        dadosSubestacao[IDsubestacao].IDbarrasAssociadas[contadorBarrasAssociadas] = IDbarraAssociada;
        quantidadeRamosAssociados = 0;
        quantidadeGeradoresAssociados = 0;
        quantidadeCargasAssociadas = 0;
        quantidadeShuntsAssociados = 0; 
        quantidadeMedidoresAssociados = 0;
        dadosBarra[IDbarraAssociada].energizada = False;
        for(contadorBarrasCaminho=0; contadorBarrasCaminho<dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].tamanho; contadorBarrasCaminho++){
            IDbarraCaminho = dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[contadorBarrasAssociadas].IDbarras[contadorBarrasCaminho];
            dadosBarra[IDbarraCaminho].numeroBarraAssociada = numeroBarrasAssociada;
            dadosBarra[IDbarraCaminho].IDbarraAssociada = IDbarraAssociada;
            //printf("\nBarra %d com %d ramos adjacentes",dadosBarra[IDbarraCaminho].numeroBarra, dadosBarra[IDbarraCaminho].quantidadeRamosAdjacentes);
            for(i=0; i<dadosBarra[IDbarraCaminho].quantidadeRamosAdjacentes; i++){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDramosTracking,quantidadeRamosAssociados,dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]);
                if(!existe){
                    dadosBarra[IDbarraAssociada].IDramosTracking[quantidadeRamosAssociados] = dadosBarra[IDbarraCaminho].IDramosAdjacentes[i];
                    if(dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDe == IDbarraCaminho){
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDeTracking = IDbarraAssociada;
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].barraDeTracking = numeroBarrasAssociada;
                    }
                    else{
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraParaTracking = IDbarraAssociada;
                        dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].barraParaTracking = numeroBarrasAssociada;
                    }
                    quantidadeRamosAssociados++;
                }
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDramosAssociados,dadosBarra[IDbarraAssociada].quantidadeRamosAssociados,dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]);
                if(!existe){
                    dadosBarra[IDbarraAssociada].modificadaTracking = True;
                    alteraValor(barrasAfetadas,0,IDbarraAssociada,1);
                    alteraValor(ramosAfetados, 0, dadosBarra[IDbarraCaminho].IDramosAdjacentes[i], 1);
                    //printf("\nBarra %d associada a barra %d. (1)", dadosBarra[IDbarraCaminho].numeroBarra, dadosBarra[IDbarraAssociada].numeroBarra);
                    if(dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDe == IDbarraCaminho){
                        alteraValor(barrasAfetadas,0,dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraParaAssociada, 1);
                        dadosBarra[dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraParaAssociada].barraVizinhaTracking = True;
                    }
                    else{
                        alteraValor(barrasAfetadas, 0, dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDeAssociada, 1);
                        dadosBarra[dadosRamo[dadosBarra[IDbarraCaminho].IDramosAdjacentes[i]].IDbarraDeAssociada].barraVizinhaTracking = True;
                    }
                }
            }
            if(dadosBarra[IDbarraCaminho].IDgerador!=-1){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDgeradoresAssociados, dadosBarra[IDbarraAssociada].quantidadeGeradoresAssociados, dadosBarra[IDbarraCaminho].IDgerador);
                if(!existe){
                    dadosBarra[IDbarraAssociada].modificadaShunt = True;
                    alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
                    alteraValor(barrasAfetadas, 0, dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].IDbarraAssociada, 1);
                }
                dadosBarra[IDbarraAssociada].IDgeradoresAssociados[quantidadeGeradoresAssociados] = dadosBarra[IDbarraCaminho].IDgerador;
                dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].IDbarraAssociada = IDbarraAssociada;
                dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].barraAssociada = numeroBarrasAssociada;
                if(dadosGerador[dadosBarra[IDbarraCaminho].IDgerador].ligado==1){
                    dadosBarra[IDbarraAssociada].energizada = True;
                }
                quantidadeGeradoresAssociados++;
            }
            if(dadosBarra[IDbarraCaminho].IDcarga!=-1){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDcargasAssociadas, dadosBarra[IDbarraAssociada].quantidadeCargasAssociadas, dadosBarra[IDbarraCaminho].IDcarga);
                if(!existe){
                    dadosBarra[IDbarraAssociada].modificadaShunt = True;
                    alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
                    alteraValor(barrasAfetadas, 0, dadosCarga[dadosBarra[IDbarraCaminho].IDcarga].IDbarraAssociada, 1);
                }
                dadosBarra[IDbarraAssociada].IDcargasAssociadas[quantidadeCargasAssociadas] = dadosBarra[IDbarraCaminho].IDcarga;
                dadosCarga[dadosBarra[IDbarraCaminho].IDcarga].IDbarraAssociada = IDbarraAssociada;
                dadosCarga[dadosBarra[IDbarraCaminho].IDcarga].barraAssociada = numeroBarrasAssociada;
                quantidadeCargasAssociadas++;
            } 
            if(dadosBarra[IDbarraCaminho].IDshunt!=-1){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDshuntsAssociados, dadosBarra[IDbarraAssociada].quantidadeShuntsAssociados, dadosBarra[IDbarraCaminho].IDshunt);
                if(!existe){
                    dadosBarra[IDbarraAssociada].modificadaShunt = True;
                    alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
                    alteraValor(barrasAfetadas, 0, dadosShunt[dadosBarra[IDbarraCaminho].IDshunt].IDbarraAssociada, 1);
                }
                dadosBarra[IDbarraAssociada].IDshuntsAssociados[quantidadeShuntsAssociados] = dadosBarra[IDbarraCaminho].IDshunt;
                dadosShunt[dadosBarra[IDbarraCaminho].IDshunt].IDbarraAssociada = IDbarraAssociada;
                dadosShunt[dadosBarra[IDbarraCaminho].IDshunt].barraAssociada = numeroBarrasAssociada;
                quantidadeShuntsAssociados++;
            }
            for(i=0; i<dadosBarra[IDbarraCaminho].quantidadeMedidores; i++){
                existe = existeNoVetor(dadosBarra[IDbarraAssociada].IDmedidoresAssociados, quantidadeMedidoresAssociados, dadosBarra[IDbarraCaminho].IDmedidores[i]);
                if(!existe){
                    dadosBarra[IDbarraAssociada].IDmedidoresAssociados[quantidadeMedidoresAssociados] = dadosBarra[IDbarraCaminho].IDmedidores[i];
                    //Medição de potência
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==0){
                        if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarra==IDbarraCaminho){
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarraAssociada = IDbarraAssociada;
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.barraAssociada = numeroBarrasAssociada;
                        }
                        if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDe==IDbarraCaminho){
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDeAssociada = IDbarraAssociada;
                            dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.barraDeAssociada = numeroBarrasAssociada;
                        }
                    }
                    //Medição de tensão
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==1){
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.IDbarraAssociada = IDbarraAssociada;
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TP.barraAssociada = numeroBarrasAssociada;
                    }
                    //edição de corrente
                    if(dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].tipoMedidor==2){
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.IDbarraDeAssociada = IDbarraAssociada;
                        dadosArranjo[dadosBarra[IDbarraCaminho].IDmedidores[i]].TC.barraDeAssociada = numeroBarrasAssociada;
                    }
                    quantidadeMedidoresAssociados++;
                }
            }
            if((IDbarraCaminho!=IDbarraAssociada) && (dadosBarra[IDbarraCaminho].quantidadeRamosAssociados>0)){
                dadosBarra[IDbarraCaminho].modificadaTracking = True;
                alteraValor(barrasAfetadas, 0, IDbarraCaminho, 1);
            }
        }
        if(dadosBarra[IDbarraAssociada].quantidadeRamosAssociados != quantidadeRamosAssociados){
            dadosBarra[IDbarraAssociada].modificadaTracking = True;
            alteraValor(barrasAfetadas,0,IDbarraAssociada,1);
        }
        //Determina as barras em que houve apenas alterações na quantidade de componentes shunt e medidores
        // if(dadosBarra[IDbarraAssociada].modificadaTracking==False){
        //     if((dadosBarra[IDbarraAssociada].quantidadeGeradoresAssociados != quantidadeGeradoresAssociados)){
        //         dadosBarra[IDbarraAssociada].modificadaShunt = True;
        //         alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
        //     }
        //     else if((dadosBarra[IDbarraAssociada].quantidadeCargasAssociadas != quantidadeCargasAssociadas)){
        //         dadosBarra[IDbarraAssociada].modificadaShunt = True;
        //         alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
        //     }
        //     else if((dadosBarra[IDbarraAssociada].quantidadeShuntsAssociados != quantidadeShuntsAssociados)){
        //         dadosBarra[IDbarraAssociada].modificadaShunt = True;
        //         alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
        //     }
        //     else if((dadosBarra[IDbarraAssociada].quantidadeMedidoresAssociados != quantidadeMedidoresAssociados)){
        //         dadosBarra[IDbarraAssociada].modificadaShunt = True;
        //         alteraValor(barrasAfetadas, 0, IDbarraAssociada, 1);
        //     }
        // }
        dadosBarra[IDbarraAssociada].quantidadeRamosTracking = quantidadeRamosAssociados;
        dadosBarra[IDbarraAssociada].quantidadeGeradoresAssociados = quantidadeGeradoresAssociados;
        dadosBarra[IDbarraAssociada].quantidadeCargasAssociadas = quantidadeCargasAssociadas;
        dadosBarra[IDbarraAssociada].quantidadeShuntsAssociados = quantidadeShuntsAssociados;
        dadosBarra[IDbarraAssociada].quantidadeMedidoresAssociados = quantidadeMedidoresAssociados;
    }
    return;
}
//Rotina do Procesamento em Nível de Subestação na versão tracking
LINHA *PNStracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA *subestacoesModificadas, LINHA *ramosAfetados,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, 
                            int numeroCargas, int numeroShunts, int numeroArranjos, int numeroSubestacoes){
    int IDsubestacao, contadorChaves, sucesso, contadorBarras;
    LISTA *aux;
    LINHA *barrasAfetadas;
    barrasAfetadas = (LINHA *) malloc(sizeof(LINHA));
    if(barrasAfetadas==NULL){
        printf("\nErro na alocação de memória para barrasAfetadas.\n");
        exit(1);
    }
    barrasAfetadas[0].tamanho = 0;
    barrasAfetadas[0].head = NULL;
    //Fatoração das matrizes de incidência e identificação dos caminhos
    //de fatoração das subestações que sofreram alguma modificação
    aux = subestacoesModificadas[0].head;
    while(aux != NULL){
        IDsubestacao = aux->IDcoluna;
        //Reinicializa a matriz Hf        
        igualaMatrizes(&dadosSubestacao[IDsubestacao].Hf, dadosSubestacao[IDsubestacao].Href,dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes, dadosSubestacao[IDsubestacao].quantidadeChaves);
        //Zerar colunas da matriz Hf referentes às chaves que estão abertas
        for(contadorChaves=0; contadorChaves<dadosSubestacao[IDsubestacao].quantidadeChaves; contadorChaves++){
            if(dadosChave[dadosSubestacao[IDsubestacao].IDchavesReferencia[contadorChaves]].statusAtualizado == 0){
                //printf("\nChave %d da subestacao %d aberta.", dadosChave[dadosSubestacao[IDsubestacao].IDchavesReferencia[contadorChaves]].numeroChave, IDsubestacao+1);
                zeraColuna(&dadosSubestacao[IDsubestacao].Hf, dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes, contadorChaves);
            }
        }
        //Reinicializa arvore de fatoração
        /*for(contadorBarras=0; contadorBarras<dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes; contadorBarras++){
            dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[contadorBarras] = -1;
        }*/
        //OBS: O ideal seria igualar a matriz de fatores a uma matriz identidade antes de
        //refatorar por completo a matriz de incidência. Contudo, percebi que a matriz
        //de fatores não está sendo efetivamente utilizada no restante do código. Por isso,
        //optei por mantê-la inalterada em relação à sua versão após o configurador de rede básico.
        sucesso = fatoraMatrizAssimetrica(&dadosSubestacao[IDsubestacao].Hf,&dadosSubestacao[IDsubestacao].fatores,dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes,&dadosSubestacao[IDsubestacao].arvoreFatoracao);
        if(sucesso == 1){
            printf("\n\n\nErro ao fatorar a matriz de incidencia da subestaçao %d.\n\n\n", dadosSubestacao[IDsubestacao].IDsubestacao);
            exit(1);
        }
        // for(contadorBarras=0; contadorBarras<dadosSubestacao[IDsubestacao].quantidadeBarrasRelevantes; contadorBarras++){
        //     //dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[contadorBarras] = -1;
        //     if(dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[contadorBarras]==-1){
        //         printf("\nNo %d, proximo: %d", dadosBarra[dadosSubestacao[IDsubestacao].IDbarrasRelevantes[contadorBarras]].numeroBarra,-1);
        //     }
        //     else{
        //         printf("\nNo %d, proximo: %d", dadosBarra[dadosSubestacao[IDsubestacao].IDbarrasRelevantes[contadorBarras]].numeroBarra, dadosBarra[dadosSubestacao[IDsubestacao].IDbarrasRelevantes[dadosSubestacao[IDsubestacao].arvoreFatoracao.proximoNo[contadorBarras]]].numeroBarra);
        //     }
        // }
        //Identifica os caminhos de fatoração
        listaCaminhosFatoracaoSubestacao(dadosSubestacao, IDsubestacao);
        //Print os caminhos de fatoração
        //  for(int i=0; i<dadosSubestacao[IDsubestacao].quantidadeBarrasAssociadas; i++){
        //      printf("\nCaminho %d da subestacao %d:",i+1,IDsubestacao+1);
        //      for(int j=0; j<dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].tamanho; j++){
        //          printf(" %d", dadosBarra[dadosSubestacao[IDsubestacao].listaCaminhosFatoracao[i].IDbarras[j]].numeroBarra);
        //      }
        //      printf("\n");
        //  }
        //Associação das barras por subestação
        associaBarrasPorSubestacaoTracking(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                            dadosShunt, dadosArranjo, dadosSubestacao, &barrasAfetadas, &ramosAfetados, numeroBarras,
                            numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                            numeroShunts, numeroArranjos, numeroSubestacoes, IDsubestacao);
        //printf("\n\n\nCHEGUEI AQUI\n\n\n");
        aux = aux->proximo;
    }
    //Print informações da barra de ID 1604
    // printf("\nBarra 1604: %d",dadosBarra[1604].numeroBarra);
    // printf("\nQuantidade de ramos associados: %d", dadosBarra[1604].quantidadeRamosAssociados);
    // printf("\nQuantidade de ramos tracking: %d", dadosBarra[1604].quantidadeRamosTracking);
    return barrasAfetadas;
}
//Rotina para identificar as barras pertencentes ao caminho de fatoração que deverá ser refatorado
LINHA *identificaBarrasCaminhoFatoracao(DBAR *dadosBarra, LINHA *barrasAfetadas){
    int barraAtual, noAtual;
    double valor;
    LINHA *barrasCaminhoFatoracao;
    LISTA *aux;
    BOOL noJuncao, fimCaminho;
    barrasCaminhoFatoracao = (LINHA *) malloc(sizeof(LINHA));
    if(barrasCaminhoFatoracao==NULL){
        printf("\nErro na alocação de memória para barrasCaminhoFatoracao.\n");
        exit(1);
    }
    barrasCaminhoFatoracao[0].tamanho = 0;
    barrasCaminhoFatoracao[0].head = NULL;
    aux = barrasAfetadas[0].head;
    while(aux!=NULL){
        barraAtual = aux->IDcoluna;
        //printf("\nBarra %d:", dadosBarra[barraAtual].numeroBarra);
        // if((dadosBarra[barraAtual].numeroBarra==60118) && dadosBarra[barraAtual].modificadaShunt){
        //     printf("\nOLHA SOOOOOOOOO\n");
        //     exit(1);
        // }
        if((dadosBarra[barraAtual].modificadaTracking==True) || (dadosBarra[barraAtual].barraVizinhaTracking==True)){
            noAtual = barraAtual;
            noJuncao = False;
            fimCaminho = False;
            while(!fimCaminho && !noJuncao){
                valor = consultaValor(barrasCaminhoFatoracao,0,noAtual);
                if(valor == 0){
                    alteraValor(&barrasCaminhoFatoracao,0,noAtual,1);
                    dadosBarra[noAtual].caminhoTracking = True;
                    noAtual = dadosBarra[noAtual].proximoNo;
                    if(noAtual == -1){
                        fimCaminho = True;
                    }
                }
                else{
                    noJuncao = True;
                }
            }
        }
        aux = aux->proximo;
    }
    return barrasCaminhoFatoracao;
}
//Rotina para aplicar as modificações na matriz Y recuperada
void aplicaModificacoesMatrizY(LINHA *matrizYrecuperada, LINHA *barrasAfetadas, LINHA *ramosAfetados, LINHA *barrasAssociadas, DBAR *dadosBarra, DRAM *dadosRamo){
    int IDbarra, IDramo, IDbarraDe, IDbarraPara;
    double valor;
    LISTA *auxBarra, *auxRamo;
    //Modificação dos elementos não diagonais da matriz Y
    auxRamo = ramosAfetados[0].head;
    while(auxRamo!=NULL){
        IDramo = auxRamo->IDcoluna;
        //Printar todas as informações do ramo
        // printf("\nRamo %d:", IDramo+1);
        // printf("\nBarra de: %d", dadosRamo[IDramo].IDbarraDeAssociada+1);
        // printf("\nBarra para: %d", dadosRamo[IDramo].IDbarraParaAssociada+1);
        // printf("\nBarra de tracking: %d", dadosRamo[IDramo].IDbarraDeTracking+1);
        // printf("\nBarra para tracking: %d", dadosRamo[IDramo].IDbarraParaTracking+1);
        // printf("\nTipo: %d", dadosRamo[IDramo].tipo);
        //printf("\n");
        //Modificações na matriz Y
        if((dadosRamo[IDramo].barraDeTracking==-1) && (dadosRamo[IDramo].barraParaTracking!=-1)){
            IDbarraDe = dadosRamo[IDramo].IDbarraDeAssociada;
            IDbarraPara = dadosRamo[IDramo].IDbarraParaAssociada;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor + 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
            IDbarraPara = dadosRamo[IDramo].IDbarraParaTracking;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor - 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
        }
        else if((dadosRamo[IDramo].barraDeTracking!=-1) && (dadosRamo[IDramo].barraParaTracking==-1)){
            IDbarraDe = dadosRamo[IDramo].IDbarraDeAssociada;
            IDbarraPara = dadosRamo[IDramo].IDbarraParaAssociada;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor + 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
            IDbarraDe = dadosRamo[IDramo].IDbarraDeTracking;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor - 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
        }
        else if((dadosRamo[IDramo].barraDeTracking!=-1) && (dadosRamo[IDramo].barraParaTracking!=-1)){
            IDbarraDe = dadosRamo[IDramo].IDbarraDeAssociada;
            IDbarraPara = dadosRamo[IDramo].IDbarraParaAssociada;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor + 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
            IDbarraDe = dadosRamo[IDramo].IDbarraDeTracking;
            IDbarraPara = dadosRamo[IDramo].IDbarraParaTracking;
            valor = consultaValor(matrizYrecuperada, IDbarraDe, IDbarraPara);
            valor = valor - 1;
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, valor);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, valor);
            }
            else{
                alteraValor(&matrizYrecuperada, IDbarraDe, IDbarraPara, 0);
                alteraValor(&matrizYrecuperada, IDbarraPara, IDbarraDe, 0);
            }
        }
        auxRamo = auxRamo->proximo;
    }
    //Modificação dos elementos diagonais da matriz Y
    auxBarra = barrasAfetadas[0].head;
    while(auxBarra!=NULL){
        IDbarra = auxBarra->IDcoluna;
        if(dadosBarra[IDbarra].modificadaTracking){
            if(dadosBarra[IDbarra].quantidadeRamosAssociados != dadosBarra[IDbarra].quantidadeRamosTracking){
                valor = consultaValor(matrizYrecuperada, IDbarra, IDbarra);
                valor = valor + dadosBarra[IDbarra].quantidadeRamosTracking - dadosBarra[IDbarra].quantidadeRamosAssociados;
                if(fabs(valor)>0.0000000001){
                    alteraValor(&matrizYrecuperada, IDbarra, IDbarra, valor);
                }
                else{
                    alteraValor(&matrizYrecuperada, IDbarra, IDbarra, 0);
                }
                if(dadosBarra[IDbarra].quantidadeRamosTracking==0){
                    //Elimina uma barra do conjunto de barras associadas
                    alteraValor(&barrasAssociadas,0,IDbarra,0);
                    dadosBarra[IDbarra].IDcaminhoFatoracao = -1;
                }
                if(dadosBarra[IDbarra].quantidadeRamosAssociados==0){
                    //Adiciona uma barra ao conjunto de barras associadas
                    alteraValor(&barrasAssociadas, 0, IDbarra, 1);
                    dadosBarra[IDbarra].IDcaminhoFatoracao = -1;
                }
            }
        }
        auxBarra = auxBarra->proximo;
    }
    return;
}
//Rotina para preencher a matriz de admitância primitiva/Adjacência no caso do configurador tracking
void constroiMatrizYtracking(LINHA *matrizY, LINHA *barrasAfetadas, LINHA *barrasAssociadas, DBAR *dadosBarra, DRAM *dadosRamo){
    int IDbarra, IDramo, IDbarraDe, IDbarraPara, contadorAdjacentes, ramoAdjacente;
    double valor;
    LISTA *auxBarra;
    auxBarra = barrasAfetadas[0].head;
    while(auxBarra!=NULL){
        IDbarra = auxBarra->IDcoluna;
        if(dadosBarra[IDbarra].modificadaTracking){
            if(dadosBarra[IDbarra].quantidadeRamosTracking==0){
                //Elimina uma barra do conjunto de barras associadas
                alteraValor(&barrasAssociadas, 0, IDbarra, 0);
                dadosBarra[IDbarra].IDcaminhoFatoracao = -1;
                dadosBarra[IDbarra].proximoNo = -1;
            }
            if(dadosBarra[IDbarra].quantidadeRamosAssociados==0){
                //Adiciona uma barra ao conjunto de barras associadas
                alteraValor(&barrasAssociadas, 0, IDbarra, 1);
                dadosBarra[IDbarra].IDcaminhoFatoracao = -1;
            }
        }
        auxBarra = auxBarra->proximo;
    }
    auxBarra = barrasAssociadas[0].head;
    while(auxBarra!=NULL){
        IDbarra = auxBarra->IDcoluna;
        if(dadosBarra[IDbarra].modificadaTracking){
            alteraValor(&matrizY, IDbarra, IDbarra, dadosBarra[IDbarra].quantidadeRamosTracking);
            for(contadorAdjacentes=0; contadorAdjacentes<dadosBarra[IDbarra].quantidadeRamosTracking; contadorAdjacentes++){
                ramoAdjacente = dadosBarra[IDbarra].IDramosTracking[contadorAdjacentes];
                if((dadosRamo[ramoAdjacente].IDbarraDeTracking==IDbarra) || ((dadosRamo[ramoAdjacente].IDbarraDeTracking==-1) && (dadosRamo[ramoAdjacente].IDbarraDeAssociada==IDbarra))){
                    if(dadosRamo[ramoAdjacente].IDbarraParaTracking!=-1){
                        IDbarraPara = dadosRamo[ramoAdjacente].IDbarraParaTracking;
                    }
                    else{
                        IDbarraPara = dadosRamo[ramoAdjacente].IDbarraParaAssociada;
                    }
                    valor = consultaValor(matrizY, IDbarra, IDbarraPara);
                    valor = valor - 1;
                    alteraValor(&matrizY, IDbarra, IDbarraPara, valor);
                }
                else if((dadosRamo[ramoAdjacente].IDbarraParaTracking==IDbarra) || ((dadosRamo[ramoAdjacente].IDbarraParaTracking==-1) && (dadosRamo[ramoAdjacente].IDbarraParaAssociada==IDbarra))){
                    if(dadosRamo[ramoAdjacente].IDbarraDeTracking!=-1){
                        IDbarraDe = dadosRamo[ramoAdjacente].IDbarraDeTracking;
                    }
                    else{
                        IDbarraDe = dadosRamo[ramoAdjacente].IDbarraDeAssociada;
                    }
                    valor = consultaValor(matrizY, IDbarra, IDbarraDe);
                    valor = valor - 1;
                    alteraValor(&matrizY, IDbarra, IDbarraDe, valor);
                }
                else{
                    printf("\nErro na matriz Y - Tracking");
                    printf("\nBarra %d", IDbarra);
                    printf("\nRamo %d", ramoAdjacente);
                    printf("\nBarra de: %d", dadosRamo[ramoAdjacente].IDbarraDeAssociada);
                    printf("\nBarra para: %d", dadosRamo[ramoAdjacente].IDbarraParaAssociada);
                    printf("\nBarra de tracking: %d", dadosRamo[ramoAdjacente].IDbarraDeTracking);
                    printf("\nBarra para tracking: %d", dadosRamo[ramoAdjacente].IDbarraParaTracking);
                    exit(1);
                }
            }
        }
        else{
            alteraValor(&matrizY, IDbarra, IDbarra, dadosBarra[IDbarra].quantidadeRamosAssociados);
            for(contadorAdjacentes=0; contadorAdjacentes<dadosBarra[IDbarra].quantidadeRamosAssociados; contadorAdjacentes++){
                ramoAdjacente = dadosBarra[IDbarra].IDramosAssociados[contadorAdjacentes];
                if((dadosRamo[ramoAdjacente].IDbarraDeTracking==IDbarra) || ((dadosRamo[ramoAdjacente].IDbarraDeTracking==-1) && (dadosRamo[ramoAdjacente].IDbarraDeAssociada==IDbarra))){
                    if(dadosRamo[ramoAdjacente].IDbarraParaTracking!=-1){
                        IDbarraPara = dadosRamo[ramoAdjacente].IDbarraParaTracking;
                    }
                    else{
                        IDbarraPara = dadosRamo[ramoAdjacente].IDbarraParaAssociada;
                    }
                    valor = consultaValor(matrizY, IDbarra, IDbarraPara);
                    valor = valor - 1;
                    alteraValor(&matrizY, IDbarra, IDbarraPara, valor);
                }
                else if((dadosRamo[ramoAdjacente].IDbarraParaTracking==IDbarra) || ((dadosRamo[ramoAdjacente].IDbarraParaTracking==-1) && (dadosRamo[ramoAdjacente].IDbarraParaAssociada==IDbarra))){
                    if(dadosRamo[ramoAdjacente].IDbarraDeTracking!=-1){
                        IDbarraDe = dadosRamo[ramoAdjacente].IDbarraDeTracking;
                    }
                    else{
                        IDbarraDe = dadosRamo[ramoAdjacente].IDbarraDeAssociada;
                    }
                    valor = consultaValor(matrizY, IDbarra, IDbarraDe);
                    valor = valor - 1;
                    alteraValor(&matrizY, IDbarra, IDbarraDe, valor);
                }
                else{
                    printf("\nErro na matriz Y");
                    printf("\nBarra %d", IDbarra);
                    printf("\nRamo %d", ramoAdjacente);
                    printf("\nBarra de: %d", dadosRamo[ramoAdjacente].IDbarraDeAssociada);
                    printf("\nBarra para: %d", dadosRamo[ramoAdjacente].IDbarraParaAssociada);
                    printf("\nBarra de tracking: %d", dadosRamo[ramoAdjacente].IDbarraDeTracking);
                    printf("\nBarra para tracking: %d", dadosRamo[ramoAdjacente].IDbarraParaTracking);
                    exit(1);
                }
            }
        }
        auxBarra = auxBarra->proximo;
    }
    return;
}
//Rotina para Processamento em Nível de Rede na versão tracking
void PNRtracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA *subestacoesModificadas, LINHA *barrasAfetadas, LINHA *ramosAfetados,
                            LINHA **matrizY, LINHA **fatoresY, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, 
                            int numeroCargas, int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas){
    double proporcao; //Variável usada para comparar o tamanho do caminho de refatoração com o tamanho da matriz fatorada da execução anterior
    double limiar = 0.5; //Limiar usado para determinar a partir de qual percentual o código irá optar pela refatoração completa da matriz Y
    int sucesso, i;
    LINHA *barrasCaminhoFatoracao, *matrizYrecuperada;
    LISTA *aux;
    //struct timeval beginIdentificaCaminho, beginMultiplica, beginModifica, beginFatora, beginLista, endLista;
    //gettimeofday(&beginIdentificaCaminho, 0);

    //imprima os valores de barrasAfetadas
    // aux = barrasAfetadas[0].head;
    // while(aux!=NULL){
    //     if(aux->valor==1){
    //         printf("\nBarra %d associada.", dadosBarra[aux->IDcoluna].numeroBarra);
    //     }
    //     aux = aux->proximo;
    // }

    barrasCaminhoFatoracao = identificaBarrasCaminhoFatoracao(dadosBarra, barrasAfetadas);
    proporcao = (double)barrasCaminhoFatoracao[0].tamanho/(double)barrasAssociadas[0].tamanho;
    if(proporcao>limiar){
        //double start_timeTR = omp_get_wtime();
        //printf("\nProporcao: %f\n",proporcao);
        //----------------------------------------------------------------
        //Refatoração completa da matriz Y
        //----------------------------------------------------------------
        //Zerando a matriz Y e igualando a matriz de fatores à identidade
        aux = barrasAssociadas[0].head;
        while(aux!=NULL){
            i = aux->IDcoluna;
            (*matrizY)[i].tamanho = 0;
            (*matrizY)[i].head = NULL;
            (*fatoresY)[i].tamanho = 0;
            (*fatoresY)[i].head = NULL;
            alteraValor(fatoresY, i, i, 1);
            aux = aux->proximo;
        }
        constroiMatrizYtracking(*matrizY, barrasAfetadas, barrasAssociadas, dadosBarra, dadosRamo);
        sucesso = fatoraMatrizSimetrica(matrizY, fatoresY, &barrasAssociadas, dadosBarra);
        if(sucesso == 1){
            printf("\n\n\nErro ao fatorar a matriz de incidencia.\n\n\n");
            exit(1);
        }
        numeroIlhas[0] = listaCaminhosEVerificaIlhaEnergizada(dadosBarra, caminhosFatoracao, barrasAssociadas);
        //double elapsed_timeTR = omp_get_wtime() - start_timeTR;
        //printf("\nTempo transcorrido no PNRT: %f\n",elapsed_timeTR);
    }
    else{
        //----------------------------------------------------------------
        //Refatoração parcial da matriz Y
        //----------------------------------------------------------------
        // aux = barrasCaminhoFatoracao[0].head;
        // while(aux!=NULL){
        //     if(aux->valor==1){
        //         printf("\nBarra %d do caminho de fatoracao.", dadosBarra[aux->IDcoluna].numeroBarra);
        //     }
        //     aux = aux->proximo;
        // }
        //printf("\nQuantidade barras caminho de fatoracao: %d\n",barrasCaminhoFatoracao[0].tamanho);
        // aux = barrasCaminhoFatoracao[0].head;
        //  while(aux!=NULL){
        //      printf("\nBarra %d pertence ao caminho de fatoracao.", dadosBarra[aux->IDcoluna].numeroBarra);
        //      aux = aux->proximo;
        //  }
        //gettimeofday(&beginMultiplica, 0);
        //Recupera a porção da matriz Y que será refatorada
        matrizYrecuperada = multiplicaMatrizesCaminhoFatoracao(*fatoresY,*matrizY,barrasCaminhoFatoracao, dadosBarra, numeroBarras);
        //gettimeofday(&beginModifica, 0);
        //Aplica as modificações necessárias na porção da matriz Y que será refatorada
        //imprimeMatriz(matrizYrecuperada, numeroBarras);
        aplicaModificacoesMatrizY(matrizYrecuperada, barrasAfetadas, ramosAfetados, barrasAssociadas, dadosBarra, dadosRamo);
        //gettimeofday(&beginFatora, 0);
        //Refatoração da matriz
        fatoraMatrizSimetrica(&matrizYrecuperada, fatoresY, &barrasCaminhoFatoracao, dadosBarra);
        //aux = barrasAssociadas[0].head;
        // while(aux!=NULL){
        //     printf("\nBarra %d, ID: %d, proximo no: %d",dadosBarra[aux->IDcoluna].numeroBarra,aux->IDcoluna,dadosBarra[aux->IDcoluna].proximoNo);
        //     aux = aux->proximo;
        // }
        // exit(1);
        //Print barras associadas
        /*aux = barrasAssociadas[0].head;
        while(aux!=NULL){
            if(aux->valor==1){
                printf("\nBarra %d associada.", dadosBarra[aux->IDcoluna].numeroBarra);
            }
            aux = aux->proximo;
        }*/
        //gettimeofday(&beginLista, 0);
        numeroIlhas[0] = listaCaminhosEVerificaIlhaEnergizada(dadosBarra, caminhosFatoracao, barrasAssociadas);
        //printf("\nVeio ate aqui\n");
        //printf("\nCHEGUEI AQUI\n");
        //gettimeofday(&endLista, 0);

        /*long secondsIdentifica = beginMultiplica.tv_sec - beginIdentificaCaminho.tv_sec;
        long microsecondsIdentifica = beginMultiplica.tv_usec - beginIdentificaCaminho.tv_usec;
        double elapsedIdentifica = secondsIdentifica + microsecondsIdentifica*1e-6;

        long secondsMultiplica = beginModifica.tv_sec - beginMultiplica.tv_sec;
        long microsecondsMultiplica = beginModifica.tv_usec - beginMultiplica.tv_usec;
        double elapsedMultiplica = secondsMultiplica + microsecondsMultiplica*1e-6;

        long secondsModifica = beginFatora.tv_sec - beginModifica.tv_sec;
        long microsecondsModifica = beginFatora.tv_usec - beginModifica.tv_usec;
        double elapsedModifica = secondsModifica + microsecondsModifica*1e-6;

        long secondsFatora = beginLista.tv_sec - beginFatora.tv_sec;
        long microsecondsFatora = beginLista.tv_usec - beginFatora.tv_usec;
        double elapsedFatora = secondsFatora + microsecondsFatora*1e-6;

        long secondsLista = endLista.tv_sec - beginLista.tv_sec;
        long microsecondsLista = endLista.tv_usec - beginLista.tv_usec;
        double elapsedLista = secondsLista + microsecondsLista*1e-6;

        printf("\nTime measured for identifica caminho fatoracao: %.10f microsseconds.\n", elapsedIdentifica*1e6);
        printf("\nTime measured for multiplica matriz: %.10f microsseconds.\n", elapsedMultiplica*1e6);
        printf("\nTime measured for modifica a matriz: %.10f microsseconds.\n", elapsedModifica*1e6);
        printf("\nTime measured for fatora a matriz: %.10f microsseconds.\n", elapsedFatora*1e6);
        printf("\nTime measured for lista novas redes energizadas: %.10f microsseconds.\n", elapsedLista*1e6);*/
        //printf("\n\n\nCHEGUEI AQUI\n\n\n");
    }
    return;
}
//Rotina principal do configurador Tracking
double configuradorTracking(DBAR *dadosBarra, DRAM *dadosRamo, DCHAVE *dadosChave, DGEN *dadosGerador, DCARGA *dadosCarga,
                            DSHUNT *dadosShunt, DARRANJO *dadosArranjo, DSUBESTACAO *dadosSubestacao, LINHA **matrizY, LINHA **fatoresY, LINHA *barrasAssociadas, CAMINHO *caminhosFatoracao,
                            int numeroBarras, int numeroRamos, int numeroChaves, int numeroGeradores, int numeroCargas,
                            int numeroShunts, int numeroArranjos, int numeroSubestacoes, int *numeroIlhas){
    LINHA *subestacoesModificadas, *barrasAfetadas, *ramosAfetados;
    ramosAfetados = (LINHA *) malloc(sizeof(LINHA));
    if(ramosAfetados==NULL){
        printf("\nErro na alocação de memória para ramosAfetados.\n");
        exit(1);
    }
    ramosAfetados[0].tamanho = 0;
    ramosAfetados[0].head = NULL;
    subestacoesModificadas = identificaSubestacoesModificadas(dadosChave, numeroChaves);
    barrasAfetadas = PNStracking(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                                    dadosShunt, dadosArranjo, dadosSubestacao, subestacoesModificadas, ramosAfetados, numeroBarras,
                                    numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                                    numeroShunts, numeroArranjos, numeroSubestacoes);
    double start_timeTR = omp_get_wtime();
    PNRtracking(dadosBarra, dadosRamo, dadosChave, dadosGerador, dadosCarga,
                    dadosShunt, dadosArranjo, dadosSubestacao, subestacoesModificadas, barrasAfetadas, ramosAfetados,
                    matrizY, fatoresY, barrasAssociadas, caminhosFatoracao,
                    numeroBarras, numeroRamos, numeroChaves, numeroGeradores, numeroCargas,
                    numeroShunts, numeroArranjos, numeroSubestacoes, numeroIlhas);
    processaMedicao(dadosBarra, dadosRamo, dadosGerador, dadosCarga, dadosShunt, dadosArranjo, barrasAfetadas, caminhosFatoracao);
    double elapsed_timeTR = omp_get_wtime() - start_timeTR;

    return elapsed_timeTR;
}