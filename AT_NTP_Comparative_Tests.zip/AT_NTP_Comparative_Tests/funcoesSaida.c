#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "data_structures.h"
#include "funcoesLeitura.h"
#include "funcoesMatematicas.h"
#include "funcoesTopologia.h"
#include "funcoesSaida.h"
//Rotina para imprimir as medidas
void imprimeMedidas(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao){
    int barraAtual, IDilha, contadorMedidas, barraPara;
    LISTA *auxBarra;
    FILE *arquivoSaida;
    auxBarra = barrasAssociadas[0].head;
    arquivoSaida = fopen("DMED_CR.csv","w");
    while(auxBarra != NULL){
        barraAtual = auxBarra->IDcoluna;
        //printf("\n\nBarra atual: %d",dadosBarra[barraAtual].numeroBarra);
        IDilha = dadosBarra[barraAtual].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            //printf(" Numero Medidas: %d", dadosBarra[barraAtual].quantidadeMedidas);
            for(contadorMedidas=0; contadorMedidas<dadosBarra[barraAtual].quantidadeMedidas; contadorMedidas++){
                if(dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara!=-1){
                    barraPara = dadosBarra[dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara].numeroBarra;
                }
                else{
                    barraPara = -1;
                }
                fprintf(arquivoSaida, "%d,%d,%d\n",dadosBarra[barraAtual].medidas[contadorMedidas].tipo, dadosBarra[barraAtual].numeroBarra, barraPara);
            }
        }
        auxBarra = auxBarra->proximo;
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de barra
void imprimeBarras(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao){
    int barraAtual, IDilha;
    LISTA *auxBarra;
    FILE *arquivoSaida;
    auxBarra = barrasAssociadas[0].head;
    arquivoSaida = fopen("DBAR_CR.csv","w");
    while(auxBarra != NULL){
        barraAtual = auxBarra->IDcoluna;
        IDilha = dadosBarra[barraAtual].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            fprintf(arquivoSaida, "%d,%d\n", dadosBarra[barraAtual].subestacao, dadosBarra[barraAtual].numeroBarra);
        }
        auxBarra = auxBarra->proximo;
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de ramos
void imprimeRamos(DBAR *dadosBarra, DRAM *dadosRamo, CAMINHO *caminhoFatoracao, int numeroRamos){
    int IDbarraDe, IDilha, contadorRamos;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DRAM_CR.csv", "w");
    for(contadorRamos=0; contadorRamos<numeroRamos; contadorRamos++){
        IDbarraDe = dadosRamo[contadorRamos].IDbarraDeAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            fprintf(arquivoSaida, "%d,%d,%d\n", dadosRamo[contadorRamos].tipo, dadosRamo[contadorRamos].barraDeAssociada, dadosRamo[contadorRamos].barraParaAssociada);
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de geradores
void imprimeGeradores(DBAR *dadosBarra, DGEN *dadosGerador, CAMINHO *caminhoFatoracao, int numeroGeradores){
    int IDbarraDe, IDilha, contadorGeradores;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DGEN_CR.csv", "w");
    for(contadorGeradores=0; contadorGeradores<numeroGeradores; contadorGeradores++){
        IDbarraDe = dadosGerador[contadorGeradores].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                fprintf(arquivoSaida, "%d,%d,%d\n", dadosGerador[contadorGeradores].numero, dadosGerador[contadorGeradores].barraAssociada, dadosGerador[contadorGeradores].ligado);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de cargas
void imprimeCargas(DBAR *dadosBarra, DCARGA *dadosCarga, CAMINHO *caminhoFatoracao, int numeroCargas){
    int IDbarraDe, IDilha, contadorCargas;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DLOADS_CR.csv", "w");
    for(contadorCargas=0; contadorCargas<numeroCargas; contadorCargas++){
        IDbarraDe = dadosCarga[contadorCargas].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                fprintf(arquivoSaida, "%d,%d,%d\n", dadosCarga[contadorCargas].numero, dadosCarga[contadorCargas].barraAssociada, dadosCarga[contadorCargas].ligado);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de shunts
void imprimeShunts(DBAR *dadosBarra, DSHUNT *dadosShunt, CAMINHO *caminhoFatoracao, int numeroShunts){
    int IDbarraDe, IDilha, contadorShunts, injecaoPotencia, injecaoCorrente;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DSHUNT_CR.csv", "w");
    for(contadorShunts=0; contadorShunts<numeroShunts; contadorShunts++){
        IDbarraDe = dadosShunt[contadorShunts].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                if(dadosShunt[contadorShunts].possuiMedidaCorrente){
                    injecaoCorrente = 1;
                }
                else{
                    injecaoCorrente = 0;
                }
                if(dadosShunt[contadorShunts].possuiMedidaPotencia){
                    injecaoPotencia = 1;
                }
                else{
                    injecaoPotencia = 0;
                }
                fprintf(arquivoSaida, "%d,%d,%d,%d,%d\n", dadosShunt[contadorShunts].numero, dadosShunt[contadorShunts].tipo, dadosShunt[contadorShunts].barraAssociada, injecaoPotencia, injecaoCorrente);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir arquivos de saida
void imprimeSaida(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt, int numeroRamos, int numeroGeradores, int numeroCargas, int numeroShunts){
    //imprimeMedidas(dadosBarra, barrasAssociadas, caminhoFatoracao);
    imprimeBarras(dadosBarra, barrasAssociadas, caminhoFatoracao);
    imprimeRamos(dadosBarra, dadosRamo, caminhoFatoracao, numeroRamos);
    imprimeGeradores(dadosBarra, dadosGerador, caminhoFatoracao, numeroGeradores);
    imprimeCargas(dadosBarra, dadosCarga, caminhoFatoracao, numeroCargas);
    imprimeShunts(dadosBarra, dadosShunt, caminhoFatoracao, numeroShunts);
    return;
}
//-----------------------------------------------------------------------------------------
//Rotinas do Configurador Tracking
//-----------------------------------------------------------------------------------------
//Rotina para imprimir as medidas
void imprimeMedidasTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao){
    int barraAtual, IDilha, contadorMedidas, barraPara;
    LISTA *auxBarra;
    FILE *arquivoSaida;
    auxBarra = barrasAssociadas[0].head;
    arquivoSaida = fopen("DMED_TR.csv","w");
    while(auxBarra != NULL){
        barraAtual = auxBarra->IDcoluna;
        //printf("\n\nBarra atual: %d",dadosBarra[barraAtual].numeroBarra);
        IDilha = dadosBarra[barraAtual].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            //printf(" Numero Medidas: %d", dadosBarra[barraAtual].quantidadeMedidas);
            for(contadorMedidas=0; contadorMedidas<dadosBarra[barraAtual].quantidadeMedidas; contadorMedidas++){
                if(dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara!=-1){
                    barraPara = dadosBarra[dadosBarra[barraAtual].medidas[contadorMedidas].IDbarraPara].numeroBarra;
                }
                else{
                    barraPara = -1;
                }
                fprintf(arquivoSaida, "%d,%d,%d\n",dadosBarra[barraAtual].medidas[contadorMedidas].tipo, dadosBarra[barraAtual].numeroBarra, barraPara);
            }
        }
        auxBarra = auxBarra->proximo;
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de barra
void imprimeBarrasTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao){
    int barraAtual, IDilha;
    LISTA *auxBarra;
    FILE *arquivoSaida;
    auxBarra = barrasAssociadas[0].head;
    arquivoSaida = fopen("DBAR_TR.csv","w");
    while(auxBarra != NULL){
        barraAtual = auxBarra->IDcoluna;
        //printf("\n\nBarra atual: %d", dadosBarra[barraAtual].numeroBarra);
        IDilha = dadosBarra[barraAtual].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            fprintf(arquivoSaida, "%d,%d\n", dadosBarra[barraAtual].subestacao, dadosBarra[barraAtual].numeroBarra);
        }
        auxBarra = auxBarra->proximo;
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de ramos
void imprimeRamosTracking(DBAR *dadosBarra, DRAM *dadosRamo, CAMINHO *caminhoFatoracao, int numeroRamos){
    int IDbarraDe, IDilha, contadorRamos, barraDe, barraPara;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DRAM_TR.csv", "w");
    for(contadorRamos=0; contadorRamos<numeroRamos; contadorRamos++){
        if(dadosRamo[contadorRamos].IDbarraDeTracking!=-1){
            IDbarraDe = dadosRamo[contadorRamos].IDbarraDeTracking;
        }
        else{
            IDbarraDe = dadosRamo[contadorRamos].IDbarraDeAssociada;
        }
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(caminhoFatoracao[IDilha].energizado){
            if(dadosRamo[contadorRamos].IDbarraParaTracking!=-1){
                barraPara = dadosRamo[contadorRamos].barraParaTracking;
            }
            else{
                barraPara = dadosRamo[contadorRamos].barraParaAssociada;
            }
            if(dadosRamo[contadorRamos].IDbarraDeTracking!=-1){
                barraDe = dadosRamo[contadorRamos].barraDeTracking;
            }
            else{
                barraDe = dadosRamo[contadorRamos].barraDeAssociada;
            }
            fprintf(arquivoSaida, "%d,%d,%d\n", dadosRamo[contadorRamos].tipo, barraDe, barraPara);
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de geradores
void imprimeGeradoresTracking(DBAR *dadosBarra, DGEN *dadosGerador, CAMINHO *caminhoFatoracao, int numeroGeradores){
    int IDbarraDe, IDilha, contadorGeradores;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DGEN_TR.csv", "w");
    for(contadorGeradores=0; contadorGeradores<numeroGeradores; contadorGeradores++){
        IDbarraDe = dadosGerador[contadorGeradores].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                fprintf(arquivoSaida, "%d,%d,%d\n", dadosGerador[contadorGeradores].numero, dadosGerador[contadorGeradores].barraAssociada, dadosGerador[contadorGeradores].ligado);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de cargas
void imprimeCargasTracking(DBAR *dadosBarra, DCARGA *dadosCarga, CAMINHO *caminhoFatoracao, int numeroCargas){
    int IDbarraDe, IDilha, contadorCargas;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DLOADS_TR.csv", "w");
    for(contadorCargas=0; contadorCargas<numeroCargas; contadorCargas++){
        IDbarraDe = dadosCarga[contadorCargas].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                fprintf(arquivoSaida, "%d,%d,%d\n", dadosCarga[contadorCargas].numero, dadosCarga[contadorCargas].barraAssociada, dadosCarga[contadorCargas].ligado);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir os dados de shunts
void imprimeShuntsTracking(DBAR *dadosBarra, DSHUNT *dadosShunt, CAMINHO *caminhoFatoracao, int numeroShunts){
    int IDbarraDe, IDilha, contadorShunts, injecaoPotencia, injecaoCorrente;
    FILE *arquivoSaida;
    arquivoSaida = fopen("DSHUNT_TR.csv", "w");
    for(contadorShunts=0; contadorShunts<numeroShunts; contadorShunts++){
        IDbarraDe = dadosShunt[contadorShunts].IDbarraAssociada;
        IDilha = dadosBarra[IDbarraDe].IDcaminhoFatoracao;
        if(IDilha!=-1){
            if(caminhoFatoracao[IDilha].energizado){
                if(dadosShunt[contadorShunts].possuiMedidaCorrente){
                    injecaoCorrente = 1;
                }
                else{
                    injecaoCorrente = 0;
                }
                if(dadosShunt[contadorShunts].possuiMedidaPotencia){
                    injecaoPotencia = 1;
                }
                else{
                    injecaoPotencia = 0;
                }
                fprintf(arquivoSaida, "%d,%d,%d,%d,%d\n", dadosShunt[contadorShunts].numero, dadosShunt[contadorShunts].tipo, dadosShunt[contadorShunts].barraAssociada, injecaoPotencia, injecaoCorrente);
            }
        }
    }
    fclose(arquivoSaida);
    return;
}
//Rotina para imprimir arquivos de saida
void imprimeSaidaTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt, int numeroRamos, int numeroGeradores, int numeroCargas, int numeroShunts){
    //imprimeMedidasTracking(dadosBarra, barrasAssociadas, caminhoFatoracao);
    imprimeBarrasTracking(dadosBarra, barrasAssociadas, caminhoFatoracao);
    imprimeRamosTracking(dadosBarra, dadosRamo, caminhoFatoracao, numeroRamos);
    imprimeGeradoresTracking(dadosBarra, dadosGerador, caminhoFatoracao, numeroGeradores);
    imprimeCargasTracking(dadosBarra, dadosCarga, caminhoFatoracao, numeroCargas);
    imprimeShuntsTracking(dadosBarra, dadosShunt, caminhoFatoracao, numeroShunts);
    return;
}