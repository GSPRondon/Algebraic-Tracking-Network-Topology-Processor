#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "data_structures.h"
#include "funcoesLeitura.h"
#include "funcoesMatematicas.h"

//Rotina para retornar o valor armazenado na matriz
double consultaValor(LINHA *matriz, int IDlinha, int IDcoluna){
    LISTA *aux = NULL;
    aux = matriz[IDlinha].head;
    while((aux != NULL) && (aux->IDcoluna<=IDcoluna)){
        if(aux->IDcoluna == IDcoluna){
            return aux->valor;
        }
        aux = aux->proximo;
    }
    return 0;
}
//Rotina para alterar o valor armazenado na matriz 
//Caso a coluna não exista, ela é criada e o valor é inserido
//Caso a coluna já exista, o valor é alterado
//Caso o valor seja zero, a coluna é eliminada
void alteraValor(LINHA **matriz, int IDlinha, int IDcoluna, double valor){
    LISTA *aux = NULL, *novo = NULL;
    BOOL continuaBusca;
    aux = (*matriz)[IDlinha].head;
    //Exclui valor
    if(valor == 0){
        continuaBusca = True;
        while(continuaBusca){
            if(aux == NULL){
                return;
            }
            if(aux->IDcoluna == IDcoluna){
                if(aux->proximo == NULL){
                    (*matriz)[IDlinha].head = NULL;
                }else{
                    (*matriz)[IDlinha].head = aux->proximo;
                }
                //free(aux);
                (*matriz)[IDlinha].tamanho--;
                return;
            }
            if(aux->proximo != NULL){
                if(aux->proximo->IDcoluna == IDcoluna){
                    aux->proximo = aux->proximo->proximo;
                    //free(aux);
                    (*matriz)[IDlinha].tamanho--;
                    return;
                }
            }
            aux = aux->proximo;
        }
    }
    //Caso contrário, altera ou cria valor
    continuaBusca = True;
    while(continuaBusca){
        if(aux == NULL){
            novo = (LISTA*)malloc(sizeof(LISTA));
            if(novo == NULL){
                printf("Erro ao alocar memoria para novo elemento na matriz\n");
                return;
            }
            novo->IDcoluna = IDcoluna;
            novo->valor = valor;
            novo->proximo = NULL;
            (*matriz)[IDlinha].head = novo;
            (*matriz)[IDlinha].tamanho++;
            return;
        }
        if(aux->IDcoluna > IDcoluna){
            novo = (LISTA*)malloc(sizeof(LISTA));
            if(novo == NULL){
                printf("Erro ao alocar memoria para novo elemento na matriz\n");
                return;
            }
            novo->IDcoluna = IDcoluna;
            novo->valor = valor;
            novo->proximo = aux;
            (*matriz)[IDlinha].head = novo;
            (*matriz)[IDlinha].tamanho++;
            return;
        }
        if(aux->IDcoluna == IDcoluna){
            aux->valor = valor;
            return;
        }
        if(aux->proximo != NULL){
            if(aux->proximo->IDcoluna > IDcoluna){
                novo = (LISTA*)malloc(sizeof(LISTA));
                if(novo == NULL){
                    printf("Erro ao alocar memoria para novo elemento na matriz\n");
                    return;
                }
                novo->IDcoluna = IDcoluna;
                novo->valor = valor;
                novo->proximo = aux->proximo;
                aux->proximo = novo;
                (*matriz)[IDlinha].tamanho++;
                return;
            }
        }
        else{
            novo = (LISTA*)malloc(sizeof(LISTA));
            if(novo == NULL){
                printf("Erro ao alocar memoria para novo elemento na matriz\n");
                return;
            }
            novo->IDcoluna = IDcoluna;
            novo->valor = valor;
            novo->proximo = NULL;
            aux->proximo = novo;
            (*matriz)[IDlinha].tamanho++;
            return;
        }
        aux = aux->proximo;
    }

}
//Rotina para criar uma matriz identidade no formato esparso
void criaMatrizIdentidade(LINHA **matriz, int ordem){
    int i;
    (*matriz) = (LINHA*)malloc(sizeof(LINHA)*ordem);
    if((*matriz) == NULL){
        printf("Erro ao alocar memoria para matriz\n");
        return;
    }
    for(i=0; i<ordem; i++){
        (*matriz)[i].IDlinha = i;
        (*matriz)[i].tamanho = 0;
        (*matriz)[i].head = NULL;
        alteraValor(matriz, i, i, 1);
    }
}
//Rotina para imprimir a matriz no formato esparso
void imprimeMatriz(LINHA *matriz, int ordem){
    int i;
    LISTA *aux = NULL;
    for(i=0; i<ordem; i++){
        printf("linha %d: ", i);
        aux = matriz[i].head;
        while(aux != NULL){
            printf("coluna %d: %.20lf ", aux->IDcoluna, aux->valor);
            aux = aux->proximo;
        }
        printf("\n");
    }
}
/*void imprimeMatriz(LINHA *matriz, int ordem){
    int i, j;
    LISTA *aux = NULL;
    for(i=0; i<ordem; i++){
        printf("\n");
        for( j=0; j<ordem; j++){
            printf("%.2lf ", consultaValor(matriz, i, j));
        }
    }
    printf("\n");
}*/
//Rotina para permutar duas colunas de uma matriz no formato esparso
void permutaColunas(LINHA **matriz, int ordem, int coluna1, int coluna2){
    int i;
    double valorColuna1, valorColuna2;
    for(i=0; i<ordem; i++){
        valorColuna1 = consultaValor(*matriz, i, coluna1);
        valorColuna2 = consultaValor(*matriz, i, coluna2);
        alteraValor(matriz, i, coluna1, valorColuna2);
        alteraValor(matriz, i, coluna2, valorColuna1);
    }
}
//Rotina para multiplicar duas matrizes no formato esparso
LINHA* multiplicaMatrizes(LINHA *matriz1, LINHA *matriz2, int ordem1, int ordem2, int ordem3){
    int i, j, k;
    double valor;
    LINHA *matrizResultado = NULL;
    criaMatrizIdentidade(&matrizResultado, ordem1);
    for(i=0; i<ordem1; i++){
        for(j=0; j<ordem3; j++){
            valor = 0;
            for(k=0; k<ordem2; k++){
                valor += consultaValor(matriz1, i, k)*consultaValor(matriz2, k, j);
            }
            if(fabs(valor)>0.0000000001){
                alteraValor(&matrizResultado, i, j, valor);
            }
            else{
                alteraValor(&matrizResultado, i, j, 0);
            }
        }
    }
    return matrizResultado;
}
//Rotina para multiplicar duas matrizes no formato esparso, considerando apenas as linhas/colunas
//ditadas pelas barras que pertencem ao caminho de fatoração de interesse
/*LINHA* multiplicaMatrizesCaminhoFatoracao(LINHA *matriz1, LINHA *matriz2, LINHA *barrasCaminho, int numeroLinhas){
    int i, j, k, tamanho, barraInicial;
    double valor;
    LINHA *matrizResultado = NULL;
    LISTA *auxI, *auxJ, *auxK;
    inicializaMatriz(&matrizResultado, numeroLinhas);
    auxI = barrasCaminho[0].head;
    //barraInicial = barrasCaminho[0].head->IDcoluna;
    while(auxI!=NULL){
        i = auxI->IDcoluna;
        auxJ = matriz2[i].head;
        while(auxJ!=NULL){
            j = auxJ->IDcoluna;
            if(consultaValor(barrasCaminho,0,j)!=0){
                auxK = barrasCaminho[0].head;
                //printf("\n\nPASSEI POR AQUI\n\n");
                //printf("\n%d, %d",k,i);
                while((auxK!=NULL)){
                    k = auxK->IDcoluna;
                    if(k>=i){
                        valor = consultaValor(matrizResultado,j,k) + consultaValor(matriz1,j,i)*consultaValor(matriz2,i,k);
                        //alteraValor(&matrizResultado,j,k, valor);
                        if(fabs(valor)>0.0000000001){
                            alteraValor(&matrizResultado, j, k, valor);
                        }
                        else{
                            alteraValor(&matrizResultado, j, k, 0);
                        }
                    }
                    auxK = auxK->proximo;
                }
            }
            auxJ = auxJ->proximo;
        }
        auxI = auxI->proximo;
    }
    printf("\nFINALIZEI A MULTIPLICACAO\n");
    return matrizResultado;
}*/

//Rotina para multiplicar duas matrizes no formato esparso, considerando apenas as linhas/colunas
//ditadas pelas barras que pertencem ao caminho de fatoração de interesse
LINHA* multiplicaMatrizesCaminhoFatoracao(LINHA *matriz1, LINHA *matriz2, LINHA *barrasCaminho, DBAR *dadosBarra, int numeroLinhas){
    int i, j, k, tamanho, barraInicial;
    double valor, valorM1, *valorLinha;
    LINHA *matrizResultado = NULL;

    LISTA *auxI, *auxJ, *auxK;
    //double start_timeInicializa = omp_get_wtime();
    inicializaMatriz(&matrizResultado, numeroLinhas);
    //double end_timeInicializa = omp_get_wtime();
    auxI = barrasCaminho[0].head;
    //double start_timeMultiplica = omp_get_wtime();
    while(auxI!=NULL){
        i = auxI->IDcoluna;
        auxK = matriz1[i].head;
        valorLinha = (double*)calloc(numeroLinhas,sizeof(double));
        if(valorLinha==NULL){
            printf("Erro ao alocar memoria para vetor de valores\n");
            exit(1);
        }
        while(auxK!=NULL){
            k = auxK->IDcoluna;
            if(dadosBarra[k].caminhoTracking==True){
                auxJ = matriz2[k].head;
                valorM1 = consultaValor(matriz1, i, k);
                while(auxJ!=NULL){
                    j = auxJ->IDcoluna;
                    if(dadosBarra[j].caminhoTracking==True){
                        valorLinha[j] = valorLinha[j] + valorM1*consultaValor(matriz2, k, j);
                        //alteraValor(&matrizResultado, j, k, valor);
                        if(fabs(valorLinha[j])>0.0000000001){
                            alteraValor(&matrizResultado, i, j, valorLinha[j]);
                        }
                        else{
                            alteraValor(&matrizResultado, i, j, 0);
                        }
                    }
                    auxJ = auxJ->proximo;
                }
                
            }
            auxK = auxK->proximo;
        }
        /*auxK = matriz1[i].head;
        while(auxK!=NULL){
            k = auxK->IDcoluna;
            if(dadosBarra[k].caminhoTracking==True){
                auxJ = matriz2[k].head;
                while(auxJ!=NULL){
                    j = auxJ->IDcoluna;
                    if(dadosBarra[j].caminhoTracking==True){
                        //alteraValor(&matrizResultado, j, k, valor);
                        if(fabs(valorLinha[j])>0.0000000001){
                            alteraValor(&matrizResultado, i, j, valorLinha[j]);
                        }
                        else{
                            alteraValor(&matrizResultado, i, j, 0);
                        }
                    }
                    auxJ = auxJ->proximo;
                }                
            }
            auxK = auxK->proximo;
        }*/
        free(valorLinha);
        auxI = auxI->proximo;
    }
    //double end_timeMultiplica = omp_get_wtime();
    //printf("\nTempo de inicializacao: %lf\n", end_timeInicializa - start_timeInicializa);
    //printf("\nTempo de multiplicacao: %lf\n", end_timeMultiplica - start_timeMultiplica);
    //printf("\nFINALIZEI A MULTIPLICACAO\n");
    return matrizResultado;
}
/*
//Rotina para multiplicar duas matrizes no formato esparso, considerando apenas as linhas/colunas
//ditadas pelas barras que pertencem ao caminho de fatoração de interesse
LINHA* multiplicaMatrizesCaminhoFatoracao(LINHA *matriz1, LINHA *matriz2, LINHA *barrasCaminho, DBAR *dadosBarra, int numeroLinhas){
    int i, j, k, tamanho, barraInicial;
    double valor, valorM1;
    LINHA *matrizResultado = NULL;
    LISTA *auxI, *auxJ, *auxK;
    double start_timeInicializa = omp_get_wtime();
    inicializaMatriz(&matrizResultado, numeroLinhas);
    double end_timeInicializa = omp_get_wtime();
    auxI = barrasCaminho[0].head;
    double start_timeMultiplica = omp_get_wtime();
    while(auxI!=NULL){
        i = auxI->IDcoluna;
        auxK = matriz1[i].head;
        while(auxK!=NULL){
            k = auxK->IDcoluna;
            if(dadosBarra[k].caminhoTracking==True){
                auxJ = matriz2[k].head;
                valorM1 = consultaValor(matriz1, i, k);
                while(auxJ!=NULL){
                    j = auxJ->IDcoluna;
                    if(dadosBarra[j].caminhoTracking==True){
                        valor = consultaValor(matrizResultado, i, j) + valorM1*consultaValor(matriz2, k, j);
                        //alteraValor(&matrizResultado, j, k, valor);
                        if(fabs(valor)>0.0000000001){
                            alteraValor(&matrizResultado, i, j, valor);
                        }
                        else{
                            alteraValor(&matrizResultado, i, j, 0);
                        }
                    }
                    auxJ = auxJ->proximo;
                }
                
            }
            auxK = auxK->proximo;
        }
        auxI = auxI->proximo;
    }
    double end_timeMultiplica = omp_get_wtime();
    printf("\nTempo de inicializacao: %lf\n", end_timeInicializa - start_timeInicializa);
    printf("\nTempo de multiplicacao: %lf\n", end_timeMultiplica - start_timeMultiplica);
    printf("\nFINALIZEI A MULTIPLICACAO\n");
    return matrizResultado;
}*/
/*//Rotina para multiplicar duas matrizes no formato esparso, considerando apenas as linhas/colunas
//ditadas pelas barras que pertencem ao caminho de fatoração de interesse
LINHA* multiplicaMatrizesCaminhoFatoracao(LINHA *matriz1, LINHA *matriz2, LINHA *barrasCaminho, DBAR *dadosBarra, int numeroLinhas){
    int i, j, k, tamanho, barraInicial;
    double valor;
    LINHA *matrizResultado = NULL;
    LISTA *auxI, *auxJ, *auxK;
    inicializaMatriz(&matrizResultado, numeroLinhas);
    auxI = barrasCaminho[0].head;
    while(auxI!=NULL){
        i = auxI->IDcoluna;
        auxJ = matriz2[i].head;
        while(auxJ!=NULL){
            j = auxJ->IDcoluna;
            if(dadosBarra[j].caminhoTracking==False){
                alteraValor(&matriz2,i,j,0);
            }
            auxJ = auxJ->proximo; 
        }
        auxI = auxI->proximo;
    }
    auxI = barrasCaminho[0].head;
    //barraInicial = barrasCaminho[0].head->IDcoluna;
    while(auxI!=NULL){
        i = auxI->IDcoluna;
        auxJ = matriz2[i].head;
        while(auxJ!=NULL){
            j = auxJ->IDcoluna;
            //printf("\n\nPASSEI POR AQUI\n\n");
            //printf("\n%d, %d",k,i);
            if(dadosBarra[j].caminhoTracking){
                auxK = matriz2[i].head;
                while((auxK!=NULL)){
                    k = auxK->IDcoluna;
                    if(dadosBarra[k].caminhoTracking){
                        valor = consultaValor(matrizResultado,j,k) + consultaValor(matriz1,j,i)*consultaValor(matriz2,i,k);
                        //alteraValor(&matrizResultado,j,k, valor);
                        if(fabs(valor)>0.0000000001){
                            alteraValor(&matrizResultado, j, k, valor);
                        }
                        else{
                            alteraValor(&matrizResultado, j, k, 0);
                        }
                    }
                    auxK = auxK->proximo;
                }
            }
            auxJ = auxJ->proximo;
        }
        auxI = auxI->proximo;
    }
    printf("\nFINALIZEI A MULTIPLICACAO\n");
    return matrizResultado;
}*/
//Rotina para igualar duas matrizes no formato esparso
void igualaMatrizes(LINHA **matriz1, LINHA *matriz2, int numeroLinhas, int numeroColunas){
    int i, j;
    double valor;
    for(i=0; i<numeroLinhas; i++){
        (*matriz1)[i].tamanho = 0;
        (*matriz1)[i].head = NULL;
        (*matriz1)[i].IDlinha = i;
        for(j=0; j<numeroColunas; j++){
            valor = consultaValor(matriz2, i, j);
            alteraValor(matriz1, i, j, valor);
        }
    }
}
//Rotina para inicializar uma matriz esparsa
void inicializaMatriz(LINHA **matriz, int ordem){
    int i;
    (*matriz) = (LINHA*)malloc(sizeof(LINHA)*ordem);
    if((*matriz) == NULL){
        printf("Erro ao alocar memoria para matriz\n");
        return;
    }
    for(i=0; i<ordem; i++){
        (*matriz)[i].IDlinha = i;
        (*matriz)[i].tamanho = 0;
        (*matriz)[i].head = NULL;
    }
}
//Rotina para zerar colunas de uma matriz esparsa
void zeraColuna(LINHA **matriz, int ordem, int coluna){
    int i;
    for(i=0; i<ordem; i++){
        alteraValor(matriz, i, coluna, 0);
    }
}
//Rotina para buscar o próximo IDcoluna que contenha um valor não nulo na linha da matriz
int buscaProximoNaoNulo(LINHA *matriz, int IDlinha, int IDcolunaReferencia){
    LISTA *aux = NULL;
    aux = matriz[IDlinha].head;
    while(aux != NULL){
        if(aux->IDcoluna > IDcolunaReferencia){
            return aux->IDcoluna;
        }
        else if(aux->IDcoluna < IDcolunaReferencia){
            return aux->IDcoluna;
        }
        aux = aux->proximo;
    }
    return -1;
}
//Rotina para fatoração da matriz esparsa assimétrica 
int fatoraMatrizAssimetrica(LINHA **matriz, LINHA **matrizFatores, int numeroLinhas, ARVORE *arvoreFatoracao){
    int i=0, j, k, colunaPivo, linhaPivo, proximoNaoNulo, IDcoluna;
    LISTA *aux;
    BOOL primeiroNaoNulo;
    double fator, novoValor;
    //imprimeMatriz(*matriz, numeroLinhas);
    while(i<numeroLinhas){
        (*arvoreFatoracao).proximoNo[i] = -1;
        if(fabs(consultaValor(*matriz,i,i)) < 0.0000000001){
            alteraValor(matriz,i,i,0);
            colunaPivo = buscaProximoNaoNulo(*matriz, i, i);
            if(colunaPivo == -1){
                i++;
                continue;
            }
            else{
                permutaColunas(matriz, numeroLinhas, i, colunaPivo);
            }
            //printf("\nLinha: %d, Colunas Trocadas: %d/%d\n",i,i,colunaPivo);
            //imprimeMatriz(*matriz, numeroLinhas);
        }
        else{
            primeiroNaoNulo = True;
            for(j=i+1; j<numeroLinhas; j++){
                if(fabs(consultaValor(*matriz, j, i)) >= 0.0000000001){
                    fator = -(consultaValor(*matriz, j, i)/consultaValor(*matriz, i, i));
                    aux = (*matriz)[i].head;
                    //printf("\ntamanho da linha: %d\n",(*matriz)[i].tamanho);
                    while(aux!=NULL){
                        //printf("\nvalor: %lf",aux->valor);
                        //printf("\niteracao: %d",k);
                        //printf("\nIDcoluna: %d", aux->IDcoluna);
                        IDcoluna = aux->IDcoluna;
                        novoValor = (aux->valor) * fator + consultaValor(*matriz, j, IDcoluna);
                        //printf("\nnovoValor: %lf, linha pivo: %d, segunda linha: %d, coluna: %d\n", novoValor,i,j,IDcoluna);
                        if(fabs(novoValor) < 0.0000000001){
                            novoValor = 0;
                        }
                        alteraValor(matriz, j, IDcoluna, novoValor);
                        aux = aux->proximo;
                        //imprimeMatriz(*matriz, numeroLinhas);
                    }
                    //printf("\nCheguei aqui\n");
                    alteraValor(matrizFatores, j, i, -fator);
                    if(primeiroNaoNulo){
                        (*arvoreFatoracao).proximoNo[i] = j;
                        primeiroNaoNulo = False;
                    }
                }
                else{
                    alteraValor(matriz,j,i,0);
                }
            }
            i++;
        }
    }
    return 0;
}
//Rotina para fatoração da matriz esparsa simétrica
int fatoraMatrizSimetrica(LINHA **matriz, LINHA **matrizFatores, LINHA **barrasAssociadas, DBAR *dadosBarra){
    int i=0, j, k, colunaPivo, linhaPivo, proximoNaoNulo, IDcoluna;
    LISTA *auxI, *auxJ, *auxBarra;
    BOOL primeiroNaoNulo;
    double fator, novoValor;
    double valor_ii;
    auxBarra = (*barrasAssociadas)[0].head;
    while(auxBarra!=NULL){
        i = auxBarra->IDcoluna;
        dadosBarra[i].proximoNo = -1;
        if(fabs(consultaValor(*matriz,i,i)) < 0.0000000001){
            alteraValor(matriz,i,i,0);
            auxBarra = auxBarra->proximo;
        }
        else{
            primeiroNaoNulo = True;
            auxJ = (*matriz)[i].head->proximo;
            j = auxJ->IDcoluna;
            valor_ii = consultaValor(*matriz, i, i);
            while((auxJ != NULL)){
                j = auxJ->IDcoluna;
                fator = -(consultaValor(*matriz, j, i)/valor_ii);
                auxI = (*matriz)[i].head;
                while(auxI!=NULL){
                    IDcoluna = auxI->IDcoluna;
                    novoValor = (auxI->valor) * fator + consultaValor(*matriz, j, IDcoluna);
                    if(fabs(novoValor) < 0.0000000001){
                        novoValor = 0;
                    }
                    alteraValor(matriz, j, IDcoluna, novoValor);
                    auxI = auxI->proximo;
                }
                alteraValor(matrizFatores, j, i, -fator);
                if(primeiroNaoNulo){
                    if(i==j){
                        printf("\n\nERRO: i==j\n\n");
                        //Printar elementos não nulos na linha i
                        printf("\nLinha: %d",i);
                        auxI = (*matriz)[i].head;
                        while(auxI!=NULL){
                            printf("\n%d, %lf", auxI->IDcoluna, auxI->valor);
                            auxI = auxI->proximo;
                        }
                        exit(1);
                    }
                    dadosBarra[i].proximoNo = j;
                    primeiroNaoNulo = False;
                }
                auxJ = auxJ->proximo;
            }
            auxBarra = auxBarra->proximo;
        }
    }
    return 0;
}

