#ifndef funcoesMatematicas_H
#define funcoesMatematicas_H

double consultaValor(LINHA *matriz, int IDlinha, int IDcoluna);
void alteraValor(LINHA **matriz, int IDlinha, int IDcoluna, double valor);
void criaMatrizIdentidade(LINHA **matriz, int ordem);
void imprimeMatriz(LINHA *matriz, int ordem);
void permutaColunas(LINHA **matriz, int ordem, int coluna1, int coluna2);
LINHA* multiplicaMatrizes(LINHA *matriz1, LINHA *matriz2, int ordem1, int ordem2, int ordem3);
LINHA* multiplicaMatrizesCaminhoFatoracao(LINHA *matriz1, LINHA *matriz2, LINHA *barrasCaminho, DBAR *dadosBarra, int numeroLinhas);
void igualaMatrizes(LINHA **matriz1, LINHA *matriz2, int numeroLinhas, int numeroColunas);
void inicializaMatriz(LINHA **matriz, int ordem);
void zeraColuna(LINHA **matriz, int ordem, int coluna);
int buscaProximoNaoNulo(LINHA *matriz, int IDlinha, int IDcolunaReferencia);
int fatoraMatrizAssimetrica(LINHA **matriz, LINHA **matrizFatores, int numeroLinhas, ARVORE *arvoreFatoracao);
int fatoraMatrizSimetrica(LINHA **matriz, LINHA **matrizFatores, LINHA **barrasAssociadas, DBAR *dadosBarra);
#endif