#ifndef funcoesLeitura_H
#define funcoesLeitura_H

char *getfield(char *lin, int num);
void leituraDBAR(FILE *arquivo, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroBarras, int *numeroSubestacoes);
void leituraDRAM(FILE *arquivo, DRAM **dadosRamo, DBAR **dadosBarra, int *numeroRamos, int numeroBarras);
void leituraDCHAV(FILE *arquivo, DCHAVE **dadosChave, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroChaves, int numeroBarras);
void leituraDCHAVATUALIZADO(FILE *arquivo, DCHAVE **dadosChave, int arg);
void leituraDGEN(FILE *arquivo, DGEN **dadosGerador, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroGeradores, int numeroBarras);
void leituraDLOADS(FILE *arquivo, DCARGA **dadosCarga, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroCargas, int numeroBarras);
void leituraDSHUNT(FILE *arquivo, DSHUNT **dadosShunt, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroShunts, int numeroBarras);
void leituraDARRANJ(FILE *arquivo, DARRANJO **dadosArranjo, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, DGEN **dadosGerador, DCARGA **dadosCarga, DSHUNT **dadosShunt, int *numeroArranjos, int numeroBarras, int numeroGeradores, int numeroCargas, int numeroShunts);
char *leituraDados(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                    DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, int *numeroBarras,
                            int *numeroRamos, int *numeroChaves, int *numeroGeradores, int *numeroCargas,
                            int *numeroShunts, int *numeroArranjos, int *numeroSubestacoes, int arg);

#endif