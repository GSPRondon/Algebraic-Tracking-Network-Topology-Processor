#ifndef funcoesSaida_H
#define funcoesSaida_H
void imprimeMedidas(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao);
void imprimeBarras(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao);
void imprimeRamos(DBAR *dadosBarra, DRAM *dadosRamo, CAMINHO *caminhoFatoracao, int numeroRamos);
void imprimeShunts(DBAR *dadosBarra, DSHUNT *dadosShunt, CAMINHO *caminhoFatoracao, int numeroShunts);
void imprimeSaida(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt, int numeroRamos, int numeroGeradores, int numeroCargas, int numeroShunts);
void imprimeMedidasTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao);
void imprimeBarrasTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao);
void imprimeRamosTracking(DBAR *dadosBarra, DRAM *dadosRamo, CAMINHO *caminhoFatoracao, int numeroRamos);
void imprimeShuntsTracking(DBAR *dadosBarra, DSHUNT *dadosShunt, CAMINHO *caminhoFatoracao, int numeroShunts);
void imprimeSaidaTracking(DBAR *dadosBarra, LINHA *barrasAssociadas, CAMINHO *caminhoFatoracao, DRAM *dadosRamo, DGEN *dadosGerador, DCARGA *dadosCarga, DSHUNT *dadosShunt, int numeroRamos, int numeroGeradores, int numeroCargas, int numeroShunts);
#endif