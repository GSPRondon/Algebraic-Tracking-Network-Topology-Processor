#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "data_structures.h"
#include "funcoesLeitura.h"
// Lê cada campo de uma string separada por vírgula
char *getfield(char *lin, int num)
{
    char *tok;
    char *line;
    line = strdup(lin);
    //printf("\nteste -  %s",line);
    tok = strtok(line, ",\t\n\r");
    while (tok != NULL)
    {
        if (!--num)
        {
            return tok;
        }
        tok = strtok(NULL, ",\t\n\r");
    }
    return NULL;
}

//Função para leitura dos dados de barra
void leituraDBAR(FILE *arquivo, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroBarras, int *numeroSubestacoes){
    char linha[2000];
    char *dados;
    int contadorBarras = 0, contadorSubestacoes = 0, i, aux, numeroLinhas = 0, carac, *quantidadeBarrasSubestacao, *nomeSubestacaoAux;
    int IDsubestacao, **IDbarrasSubestacao; 
    BOOL subestacaoInexistente;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variáves dadosBarra
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    if(((*dadosBarra) = (DBAR *)malloc((numeroLinhas+1)*sizeof(DBAR))) == NULL){
        printf("Erro ao alocar memória para dadosBarra\n");
        exit(1);
    }
    //print numero de linhas
    nomeSubestacaoAux = (int *) malloc((numeroLinhas+1)*sizeof(int));
    quantidadeBarrasSubestacao = (int *)calloc(numeroLinhas+1, sizeof(int));
    IDbarrasSubestacao = (int **)malloc((numeroLinhas+1)*sizeof(int *));
    for(i=0; i<numeroLinhas+1; i++){
        IDbarrasSubestacao[i] = (int *)malloc((numeroLinhas+1)*sizeof(int));
    }
    rewind(arquivo);
    //Leitura do arquivo até o fim e inicialização da variávei dadosBarra
    while((fgets(linha,2000,arquivo)) != NULL){
        dados = linha;
        //Verifica se a subestação já foi criada
        subestacaoInexistente = True;
        for(i=0; i<contadorSubestacoes; i++){
            if(nomeSubestacaoAux[i] == atoi(getfield(dados,1))){
                subestacaoInexistente = False;
                IDsubestacao = i;
                IDbarrasSubestacao[IDsubestacao][quantidadeBarrasSubestacao[IDsubestacao]] = contadorBarras;
                quantidadeBarrasSubestacao[IDsubestacao]++;   
                break;        
            }
        }
        //Cria nova subestação 
        if(subestacaoInexistente){
            nomeSubestacaoAux[contadorSubestacoes] = atoi(getfield(dados, 1));
            IDsubestacao = contadorSubestacoes;
            IDbarrasSubestacao[IDsubestacao][quantidadeBarrasSubestacao[IDsubestacao]] = contadorBarras;
            quantidadeBarrasSubestacao[IDsubestacao]++;
            contadorSubestacoes++;
        }
        //Inicialização da variávei dadosBarra
        (*dadosBarra)[contadorBarras].subestacao = atoi(getfield(dados, 1));
        (*dadosBarra)[contadorBarras].IDsubestacao = IDsubestacao;
        (*dadosBarra)[contadorBarras].numeroBarra = atoi(getfield(dados, 2));
        (*dadosBarra)[contadorBarras].IDbarra = contadorBarras;
        (*dadosBarra)[contadorBarras].numeroBarraAssociada = -1;
        (*dadosBarra)[contadorBarras].IDbarraAssociada = -1;
        (*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes = 0;
        (*dadosBarra)[contadorBarras].quantidadeChavesAdjacentes = 0;
        (*dadosBarra)[contadorBarras].IDgerador = -1;
        (*dadosBarra)[contadorBarras].IDcarga = -1;
        (*dadosBarra)[contadorBarras].IDshunt = -1;
        (*dadosBarra)[contadorBarras].quantidadeBarrasAdjacentes = 0;
        (*dadosBarra)[contadorBarras].quantidadeBarrasAdjacentesAssociadas = 0;
        (*dadosBarra)[contadorBarras].quantidadeBarrasTracking = 0;
        (*dadosBarra)[contadorBarras].quantidadeMedidores = 0;
        (*dadosBarra)[contadorBarras].quantidadeRamosAssociados = 0;
        (*dadosBarra)[contadorBarras].quantidadeGeradoresAssociados = 0;
        (*dadosBarra)[contadorBarras].quantidadeCargasAssociadas = 0;
        (*dadosBarra)[contadorBarras].quantidadeShuntsAssociados = 0;
        (*dadosBarra)[contadorBarras].quantidadeMedidoresAssociados = 0;
        (*dadosBarra)[contadorBarras].quantidadeRamosTracking = 0;
        (*dadosBarra)[contadorBarras].quantidadeGeradoresTracking = 0;
        (*dadosBarra)[contadorBarras].quantidadeCargasTracking = 0;
        (*dadosBarra)[contadorBarras].quantidadeShuntsTracking = 0;
        (*dadosBarra)[contadorBarras].quantidadeMedidoresTracking = 0;
        (*dadosBarra)[contadorBarras].proximoNo = -1;
        (*dadosBarra)[contadorBarras].modificadaTracking = False;
        (*dadosBarra)[contadorBarras].modificadaShunt = False;
        (*dadosBarra)[contadorBarras].IDcaminhoFatoracao = -1;
        (*dadosBarra)[contadorBarras].caminhoTracking = False;
        (*dadosBarra)[contadorBarras].barraVizinhaTracking = False;
        contadorBarras++;
    }
    numeroBarras[0] = contadorBarras;
    numeroSubestacoes[0] = contadorSubestacoes;
    //printf("\nQuantidade de barras: %d", contadorBarras);
    //printf("\nQuantidade de subestacoes: %d", contadorSubestacoes);
    //Inicializa os dados de subestacoes
    if(((*dadosSubestacao) = (DSUBESTACAO *)malloc((contadorSubestacoes+1)*sizeof(DSUBESTACAO))) == NULL){
        printf("Erro ao alocar memória para dadosSubestacao\n");
        exit(1);
    }
    for(i=0; i<contadorSubestacoes; i++){
        (*dadosSubestacao)[i].numeroSubestacao = nomeSubestacaoAux[i];
        (*dadosSubestacao)[i].quantidadeBarras = quantidadeBarrasSubestacao[i];
        (*dadosSubestacao)[i].IDbarras = (int *)malloc(quantidadeBarrasSubestacao[i]*sizeof(int));
        //(*dadosSubestacao)[i].arvoreFatoracao.no = (int *)malloc(quantidadeBarrasSubestacao[i]*sizeof(int));
        //(*dadosSubestacao)[i].arvoreFatoracao.proximoNo = (int *)malloc(quantidadeBarrasSubestacao[i]*sizeof(int));
        for(aux=0; aux<quantidadeBarrasSubestacao[i]; aux++){
            (*dadosSubestacao)[i].IDbarras[aux] = IDbarrasSubestacao[i][aux];
            //(*dadosSubestacao)[i].arvoreFatoracao.no[aux] = aux;
            //(*dadosSubestacao)[i].arvoreFatoracao.proximoNo[aux] = -1; 
        }
        (*dadosSubestacao)[i].IDsubestacao = i;
        (*dadosSubestacao)[i].quantidadeBarrasRelevantes = 0;
        (*dadosSubestacao)[i].quantidadeBarrasIrrelevantes = 0;
        (*dadosSubestacao)[i].quantidadeBarrasAssociadas = 0;
        (*dadosSubestacao)[i].quantidadeChaves = 0;
        (*dadosSubestacao)[i].quantidadeMedidores = 0;
        (*dadosSubestacao)[i].quantidadeGeradores = 0;
        (*dadosSubestacao)[i].quantidadeCargas = 0;
        (*dadosSubestacao)[i].quantidadeShunts = 0;
    }
    //Limpeza das variáveis auxiliares
    free(nomeSubestacaoAux);
    free(quantidadeBarrasSubestacao);
    for(i=0; i<(numeroLinhas+1); i++){
        //printf("\nFim da leitura dos dados de barra\n");
        free(IDbarrasSubestacao[i]);
    }
    free(IDbarrasSubestacao);
    //printf("\nFim da leitura dos dados de barra\n");
}
//Função para leitura dos dados de ramo
void leituraDRAM(FILE *arquivo, DRAM **dadosRamo, DBAR **dadosBarra, int *numeroRamos, int numeroBarras){
    char linha[2000];
    char *dados;
    int contadorRamos = 0, i, carac, numeroLinhas = 0, contadorBarras;
    BOOL barraDeEncontrada, barraParaEncontrada;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosRamo
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosRamo) = (DRAM *)malloc((numeroLinhas+1)*sizeof(DRAM))) == NULL){
        printf("Erro ao alocar memória para dadosRamo\n");
        exit(1);
    }
    //Leitura do arquivo até o fim e inicialização da variávei dadosRamo
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        (*dadosRamo)[contadorRamos].numeroRamo = contadorRamos;
        (*dadosRamo)[contadorRamos].IDramo = contadorRamos;
        (*dadosRamo)[contadorRamos].tipo = atoi(getfield(dados, 1));
        (*dadosRamo)[contadorRamos].barraDe = atoi(getfield(dados, 2));
        (*dadosRamo)[contadorRamos].barraPara = atoi(getfield(dados, 3));
        (*dadosRamo)[contadorRamos].barraDeAssociada = -1;
        (*dadosRamo)[contadorRamos].barraParaAssociada = -1;
        (*dadosRamo)[contadorRamos].IDbarraDeAssociada = -1;
        (*dadosRamo)[contadorRamos].IDbarraParaAssociada = -1;
        (*dadosRamo)[contadorRamos].barraDeTracking = -1;
        (*dadosRamo)[contadorRamos].barraParaTracking = -1;
        (*dadosRamo)[contadorRamos].IDbarraDeTracking = -1;
        (*dadosRamo)[contadorRamos].IDbarraParaTracking = -1;
        (*dadosRamo)[contadorRamos].ligado = 1;
        barraDeEncontrada = False;
        barraParaEncontrada = False;
        contadorBarras = 0;
        while((!barraDeEncontrada || !barraParaEncontrada) && contadorBarras<numeroBarras){
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosRamo)[contadorRamos].barraDe){
                (*dadosRamo)[contadorRamos].IDbarraDe = (*dadosBarra)[contadorBarras].IDbarra;
                (*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes++;
                barraDeEncontrada = True;
            }
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosRamo)[contadorRamos].barraPara){
                (*dadosRamo)[contadorRamos].IDbarraPara = (*dadosBarra)[contadorBarras].IDbarra;
                (*dadosBarra)[contadorBarras].quantidadeRamosAdjacentes++;
                barraParaEncontrada = True;
            }
            contadorBarras++;
        }
        contadorRamos++;
    }
    numeroRamos[0] = contadorRamos;
    //printf("\nQuantidade de ramos: %d", contadorRamos);
}
//Função para leitura dos dados de chave
void leituraDCHAV(FILE *arquivo, DCHAVE **dadosChave, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroChaves, int numeroBarras){
    char linha[2000];
    char *dados;
    int contadorChaves = 0, i, carac, numeroLinhas = 0, contadorBarras;
    BOOL barraDeEncontrada, barraParaEncontrada;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosChave
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosChave) = (DCHAVE *)malloc((numeroLinhas+1)*sizeof(DCHAVE))) == NULL){
        printf("Erro ao alocar memória para dadosChave\n");
        exit(1);
    }
    //Leitura do arquivo até o fim e inicialização da variávei dadosChave
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        (*dadosChave)[contadorChaves].numeroChave = contadorChaves+1;
        (*dadosChave)[contadorChaves].IDchave = contadorChaves;
        (*dadosChave)[contadorChaves].barraDe = atoi(getfield(dados, 1));
        (*dadosChave)[contadorChaves].barraPara = atoi(getfield(dados, 2));
        (*dadosChave)[contadorChaves].status = atoi(getfield(dados, 3));
        (*dadosChave)[contadorChaves].barraDeAssociada = -1;
        (*dadosChave)[contadorChaves].barraParaAssociada = -1;
        (*dadosChave)[contadorChaves].IDbarraDeAssociada = -1;
        (*dadosChave)[contadorChaves].IDbarraParaAssociada = -1;
        barraDeEncontrada = False;
        barraParaEncontrada = False;
        contadorBarras = 0;
        while((!barraDeEncontrada || !barraParaEncontrada) && contadorBarras<numeroBarras){
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosChave)[contadorChaves].barraDe){
                (*dadosChave)[contadorChaves].IDbarraDe = (*dadosBarra)[contadorBarras].IDbarra;
                (*dadosBarra)[contadorBarras].quantidadeChavesAdjacentes++;
                barraDeEncontrada = True;
                (*dadosChave)[contadorChaves].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeChaves++;
            }
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosChave)[contadorChaves].barraPara){
                (*dadosChave)[contadorChaves].IDbarraPara = (*dadosBarra)[contadorBarras].IDbarra;
                (*dadosBarra)[contadorBarras].quantidadeChavesAdjacentes++;
                barraParaEncontrada = True;
            }
            contadorBarras++;
        }
        contadorChaves++;
    }
    numeroChaves[0] = contadorChaves;
    //printf("\nQuantidade de chaves: %d", contadorChaves);
}
//Leitura dos status atualizados das chaves (usado no tracking)
void leituraDCHAVATUALIZADO(FILE *arquivo, DCHAVE **dadosChave, int arg){
    char linha[2000];
    char *dados;
    int contadorChaves = 0;
    dados = (char *) malloc(2000 * sizeof(char));
    rewind(arquivo);
    printf("\nChave modificada: %d",arg);
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        (*dadosChave)[contadorChaves].statusAtualizado = atoi(getfield(dados, 3));
        contadorChaves++;
        /*if(contadorChaves == arg){
            if((*dadosChave)[contadorChaves-1].statusAtualizado==1){
                (*dadosChave)[contadorChaves-1].statusAtualizado = 0;
            }
            else if((*dadosChave)[contadorChaves-1].statusAtualizado==0){
                (*dadosChave)[contadorChaves-1].statusAtualizado = 1;
            }
            else{
                printf("Erro ao atualizar o status da chave\n");
                exit(1);
            }
        }*/
    }
}
//Função para leitura dos dados de geradores
void leituraDGEN(FILE *arquivo, DGEN **dadosGerador, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroGeradores, int numeroBarras){
    char linha[2000];
    char *dados;
    int contadorGeradores = 0, i, carac, numeroLinhas = 0, contadorBarras;
    BOOL barraEncontrada;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosGerador
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosGerador) = (DGEN *)malloc((numeroLinhas+1)*sizeof(DGEN))) == NULL){
        printf("Erro ao alocar memória para dadosGerador\n");
        exit(1);
    }
    //Leitura do arquivo até o fim e inicialização da variávei dadosGerador
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        //(*dadosGerador)[contadorGeradores].nome = (char *) malloc(100 * sizeof(char));
        (*dadosGerador)[contadorGeradores].numero = atoi(getfield(dados, 1));
        (*dadosGerador)[contadorGeradores].barra = atoi(getfield(dados, 2));
        (*dadosGerador)[contadorGeradores].ligado = atoi(getfield(dados, 3));
        (*dadosGerador)[contadorGeradores].IDgerador = contadorGeradores;
        (*dadosGerador)[contadorGeradores].barraAssociada = -1;
        (*dadosGerador)[contadorGeradores].IDbarraAssociada = -1;
        (*dadosGerador)[contadorGeradores].IDmedidor = -1;
        (*dadosGerador)[contadorGeradores].possuiMedidaPotencia = False;
        (*dadosGerador)[contadorGeradores].possuiMedidaCorrente = False; 
        barraEncontrada = False;
        contadorBarras = 0;
        while(!barraEncontrada && contadorBarras<numeroBarras){
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosGerador)[contadorGeradores].barra){
                (*dadosGerador)[contadorGeradores].IDbarra = (*dadosBarra)[contadorBarras].IDbarra;
                barraEncontrada = True;
                (*dadosGerador)[contadorGeradores].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeGeradores++;
                (*dadosBarra)[contadorBarras].IDgerador = contadorGeradores;
            }
            contadorBarras++;
        }
        contadorGeradores++;
    }
    numeroGeradores[0] = contadorGeradores;
}
//Função para leitura dos dados de cargas
void leituraDLOADS(FILE *arquivo, DCARGA **dadosCarga, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroCargas, int numeroBarras){
    char linha[2000];
    char *dados;
    int contadorCargas = 0, i, carac, numeroLinhas = 0, contadorBarras;
    BOOL barraEncontrada;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosCarga
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosCarga) = (DCARGA *)malloc((numeroLinhas+1)*sizeof(DCARGA))) == NULL){
        printf("Erro ao alocar memória para dadosCarga\n");
        exit(1);
    }
    //Leitura do arquivo até o fim e inicialização da variávei dadosCarga
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        //(*dadosCarga)[contadorCargas].nome = (char *) malloc(100 * sizeof(char));
        (*dadosCarga)[contadorCargas].numero = atoi(getfield(dados, 1));
        (*dadosCarga)[contadorCargas].barra = atoi(getfield(dados, 2));
        (*dadosCarga)[contadorCargas].ligado = atoi(getfield(dados, 3));
        (*dadosCarga)[contadorCargas].IDmedidor = -1;
        (*dadosCarga)[contadorCargas].IDcarga = contadorCargas;
        (*dadosCarga)[contadorCargas].barraAssociada = -1;
        (*dadosCarga)[contadorCargas].IDbarraAssociada = -1;
        (*dadosCarga)[contadorCargas].possuiMedidaPotencia = False;
        (*dadosCarga)[contadorCargas].possuiMedidaCorrente = False;
        barraEncontrada = False;
        contadorBarras = 0;
        while(!barraEncontrada && contadorBarras<numeroBarras){
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosCarga)[contadorCargas].barra){
                (*dadosCarga)[contadorCargas].IDbarra = (*dadosBarra)[contadorBarras].IDbarra;
                barraEncontrada = True;
                (*dadosCarga)[contadorCargas].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeCargas++;
                (*dadosBarra)[contadorBarras].IDcarga = contadorCargas;
                //printf("\nCarga: %d, Barra: %d, IDbarra: %d, Subestacao: %d", (*dadosCarga)[contadorCargas].nome, (*dadosCarga)[contadorCargas].barra, (*dadosCarga)[contadorCargas].IDbarra, (*dadosCarga)[contadorCargas].IDsubestacao);
            }
            contadorBarras++;
        }
        contadorCargas++;
    }
    numeroCargas[0] = contadorCargas;
}
//Função para leitura dos dados de shunts
void leituraDSHUNT(FILE *arquivo, DSHUNT **dadosShunt, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, int *numeroShunts, int numeroBarras){
    char linha[2000];
    char *dados;
    int contadorShunts = 0, i, carac, numeroLinhas = 0, contadorBarras;
    BOOL barraEncontrada;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosShunt
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosShunt) = (DSHUNT *)malloc((numeroLinhas+1)*sizeof(DSHUNT))) == NULL){
        printf("Erro ao alocar memória para dadosShunt\n");
        exit(1);
    }
    //Leitura do arquivo até o fim e inicialização da variávei dadosShunt
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        (*dadosShunt)[contadorShunts].numero = atoi(getfield(dados, 1));
        (*dadosShunt)[contadorShunts].tipo = atoi(getfield(dados, 2));
        (*dadosShunt)[contadorShunts].barra = atoi(getfield(dados, 3));
        (*dadosShunt)[contadorShunts].ligado = atoi(getfield(dados, 4));
        (*dadosShunt)[contadorShunts].IDshunt = contadorShunts;
        (*dadosShunt)[contadorShunts].barraAssociada = -1;
        (*dadosShunt)[contadorShunts].IDbarraAssociada = -1;
        (*dadosShunt)[contadorShunts].IDmedidor = -1;
        (*dadosShunt)[contadorShunts].possuiMedidaPotencia = False;
        (*dadosShunt)[contadorShunts].possuiMedidaCorrente = False;
        barraEncontrada = False;
        contadorBarras = 0;
        while(!barraEncontrada && contadorBarras<numeroBarras){
            if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosShunt)[contadorShunts].barra){
                (*dadosShunt)[contadorShunts].IDbarra = (*dadosBarra)[contadorBarras].IDbarra;
                barraEncontrada = True;
                (*dadosShunt)[contadorShunts].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeShunts++;
                (*dadosBarra)[contadorBarras].IDshunt = contadorShunts;
            }
            contadorBarras++;
        }
        contadorShunts++;
    }
    numeroShunts[0] = contadorShunts;
}   
//Função para leitura dos dados de arranjos de medição
void leituraDARRANJ(FILE *arquivo, DARRANJO **dadosArranjo, DBAR **dadosBarra, DSUBESTACAO **dadosSubestacao, DGEN **dadosGerador, DCARGA **dadosCarga, DSHUNT **dadosShunt, int *numeroArranjos, int numeroBarras, int numeroGeradores, int numeroCargas, int numeroShunts){
    char linha[2000];
    char *dados;
    int contadorArranjos = 0, i, carac, numeroLinhas = 0, contadorBarras, IDarranjo, numeroShunt, contadorGeradores, contadorCargas, contadorShunts;
    BOOL arranjoInexistente, barraDeEncontrada, barraParaEncontrada, barraLTRencontrada, geradorEncontrado, cargaEncontrada, shuntEncontrado;
    dados = (char *) malloc(2000 * sizeof(char));
    //Identificação do número de linhas para alocação da variávei dadosShunt
    while((carac = fgetc(arquivo)) != EOF){
        if(carac == '\n'){
            numeroLinhas++;
        }
    }
    rewind(arquivo);
    if(((*dadosArranjo) = (DARRANJO *)malloc((numeroLinhas+1)*sizeof(DARRANJO))) == NULL){
        printf("Erro ao alocar memória para dadosArranjo\n");
        exit(1);
    }
    while((fgets(linha, 2000, arquivo)) != NULL){
        dados = linha;
        //Verifica se o arranjo já existe
        arranjoInexistente = True;
        for(i=0; i<contadorArranjos; i++){
            if((*dadosArranjo)[i].numeroArranjo == atoi(getfield(dados, 1))){
                arranjoInexistente = False;
                IDarranjo = i;
                break;
            }
        }
        //Cria novo arranjo de medição
        if(arranjoInexistente){
            (*dadosArranjo)[contadorArranjos].numeroArranjo = atoi(getfield(dados, 1));
            (*dadosArranjo)[contadorArranjos].IDarranjo = contadorArranjos;
            (*dadosArranjo)[contadorArranjos].tipoMedidor = atoi(getfield(dados, 2));
            if(atoi(getfield(dados, 3))==0){
                //Criação do TP
                (*dadosArranjo)[contadorArranjos].TP.barra = atoi(getfield(dados, 4));
                (*dadosArranjo)[contadorArranjos].TP.barraAssociada = -1;
                (*dadosArranjo)[contadorArranjos].TP.IDbarraAssociada = -1;
                barraDeEncontrada = False;
                contadorBarras = 0;
                while(!barraDeEncontrada && contadorBarras<numeroBarras){
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[contadorArranjos].TP.barra){
                        (*dadosArranjo)[contadorArranjos].TP.IDbarra = (*dadosBarra)[contadorBarras].IDbarra;
                        barraDeEncontrada = True;
                        (*dadosArranjo)[contadorArranjos].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                        (*dadosBarra)[contadorBarras].quantidadeMedidores++;
                        (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeMedidores++;
                    }
                    contadorBarras++;
                }
            }
            else if(atoi(getfield(dados, 3))==1){
                //Criação do TC
                (*dadosArranjo)[contadorArranjos].TC.barraDe = atoi(getfield(dados, 4));
                (*dadosArranjo)[contadorArranjos].TC.barraPara = atoi(getfield(dados, 5));
                (*dadosArranjo)[contadorArranjos].tipoEquipamento = atoi(getfield(dados, 6));
                (*dadosArranjo)[contadorArranjos].TC.barraDeAssociada = -1;
                (*dadosArranjo)[contadorArranjos].TC.barraParaAssociada = -1;
                (*dadosArranjo)[contadorArranjos].TC.IDbarraDeAssociada = -1;
                (*dadosArranjo)[contadorArranjos].TC.IDbarraParaAssociada = -1;
                (*dadosArranjo)[contadorArranjos].TC.IDbarraPara = -1;
                (*dadosArranjo)[contadorArranjos].barraLTR = -1;
                (*dadosArranjo)[contadorArranjos].IDbarraLTR = -1;
                barraLTRencontrada = True;
                if(((*dadosArranjo)[contadorArranjos].tipoEquipamento==0) || ((*dadosArranjo)[contadorArranjos].tipoEquipamento==1)){
                    (*dadosArranjo)[contadorArranjos].barraLTR = atoi(getfield(dados, 7));
                    (*dadosArranjo)[contadorArranjos].barraLTRAssociada = -1;
                    (*dadosArranjo)[contadorArranjos].IDbarraLTRAssociada = -1;
                    barraLTRencontrada = False;
                }
                else{
                    numeroShunt = atoi(getfield(dados, 8));
                    if((*dadosArranjo)[contadorArranjos].tipoEquipamento==2){
                        contadorCargas = 0;
                        cargaEncontrada = False;
                        while(!cargaEncontrada && contadorCargas<numeroCargas){
                            if((*dadosCarga)[contadorCargas].numero == numeroShunt){
                                (*dadosArranjo)[contadorArranjos].IDshunt = (*dadosCarga)[contadorCargas].IDcarga;
                                (*dadosCarga)[contadorCargas].IDmedidor = contadorArranjos;
                                cargaEncontrada = True;
                                //printf("\nArranjo: %d, carga: %d", contadorArranjos, (*dadosCarga)[contadorCargas].IDcarga);
                            }
                            contadorCargas++;
                        }
                    }
                    else if((*dadosArranjo)[contadorArranjos].tipoEquipamento==3){
                        contadorShunts = 0;
                        shuntEncontrado = False;
                        while(!shuntEncontrado && contadorShunts<numeroShunts){
                            if((*dadosShunt)[contadorShunts].numero == numeroShunt){
                                (*dadosArranjo)[contadorArranjos].IDshunt = (*dadosShunt)[contadorShunts].IDshunt;
                                (*dadosShunt)[contadorShunts].IDmedidor = contadorArranjos;
                                shuntEncontrado = True;
                            }
                            contadorShunts++;
                        }
                    }
                    else if((*dadosArranjo)[contadorArranjos].tipoEquipamento==4){
                        contadorGeradores = 0;
                        geradorEncontrado = False;
                        while(!geradorEncontrado && contadorGeradores<numeroGeradores){
                            if((*dadosGerador)[contadorGeradores].numero == numeroShunt){
                                (*dadosArranjo)[contadorArranjos].IDshunt = (*dadosGerador)[contadorGeradores].IDgerador;
                                (*dadosGerador)[contadorGeradores].IDmedidor = contadorArranjos;
                                geradorEncontrado = True;
                            }
                            contadorGeradores++;
                        }
                    }
                }
                barraParaEncontrada = False;
                barraDeEncontrada = False;
                contadorBarras = 0;
                while((!barraDeEncontrada || !barraParaEncontrada || !barraLTRencontrada) && contadorBarras<numeroBarras){
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[contadorArranjos].TC.barraDe){
                        (*dadosArranjo)[contadorArranjos].TC.IDbarraDe = (*dadosBarra)[contadorBarras].IDbarra;
                        barraDeEncontrada = True;
                        (*dadosArranjo)[contadorArranjos].IDsubestacao = (*dadosBarra)[contadorBarras].IDsubestacao;
                        (*dadosBarra)[contadorBarras].quantidadeMedidores++;
                        (*dadosSubestacao)[(*dadosBarra)[contadorBarras].IDsubestacao].quantidadeMedidores++;
                    }
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[contadorArranjos].TC.barraPara){
                        (*dadosArranjo)[contadorArranjos].TC.IDbarraPara = (*dadosBarra)[contadorBarras].IDbarra;
                        barraParaEncontrada = True;
                    }
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[contadorArranjos].barraLTR){
                        (*dadosArranjo)[contadorArranjos].IDbarraLTR = (*dadosBarra)[contadorBarras].IDbarra;
                        barraLTRencontrada = True;
                    }
                    contadorBarras++;
                }
            }
            contadorArranjos++;
        }
        else{
            //Adiciona TC ou TP a medidor existente
            if(atoi(getfield(dados, 3))==0){
                //Criação do TP
                (*dadosArranjo)[IDarranjo].TP.barra = atoi(getfield(dados, 4));
                (*dadosArranjo)[IDarranjo].TP.barraAssociada = -1;
                (*dadosArranjo)[IDarranjo].TP.IDbarraAssociada = -1;
                barraDeEncontrada = False;
                contadorBarras = 0;
                while(!barraDeEncontrada && contadorBarras<numeroBarras){
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[IDarranjo].TP.barra){
                        (*dadosArranjo)[IDarranjo].TP.IDbarra = (*dadosBarra)[contadorBarras].IDbarra;
                        barraDeEncontrada = True;
                        if((*dadosArranjo)[IDarranjo].TC.IDbarraDe != (*dadosArranjo)[IDarranjo].TP.IDbarra){
                            (*dadosBarra)[contadorBarras].quantidadeMedidores++;
                        }
                    }
                    contadorBarras++;
                }
            }
            else if(atoi(getfield(dados, 3))==1){
                //Criação do TC
                (*dadosArranjo)[IDarranjo].TC.barraDe = atoi(getfield(dados, 4));
                (*dadosArranjo)[IDarranjo].TC.barraPara = atoi(getfield(dados, 5));
                (*dadosArranjo)[IDarranjo].tipoEquipamento = atoi(getfield(dados, 6));
                (*dadosArranjo)[IDarranjo].TC.barraDeAssociada = -1;
                (*dadosArranjo)[IDarranjo].TC.barraParaAssociada = -1;
                (*dadosArranjo)[IDarranjo].TC.IDbarraDeAssociada = -1;
                (*dadosArranjo)[IDarranjo].TC.IDbarraParaAssociada = -1;
                (*dadosArranjo)[IDarranjo].TC.IDbarraPara = -1;
                (*dadosArranjo)[contadorArranjos].barraLTR = -1;
                (*dadosArranjo)[contadorArranjos].IDbarraLTR = -1;
                barraLTRencontrada = True;
                //printf("\nTipo equipamento: %d\n",(*dadosArranjo)[IDarranjo].tipoEquipamento);
                if(((*dadosArranjo)[IDarranjo].tipoEquipamento==0) || ((*dadosArranjo)[IDarranjo].tipoEquipamento==1)){
                    (*dadosArranjo)[IDarranjo].barraLTR = atoi(getfield(dados, 7));
                    (*dadosArranjo)[IDarranjo].barraLTRAssociada = -1;
                    (*dadosArranjo)[IDarranjo].IDbarraLTRAssociada = -1;
                    barraLTRencontrada = False;
                }
                else{
                    numeroShunt = atoi(getfield(dados, 8));
                    //printf("\nNumero shunt: %d\n", numeroShunt);
                    if((*dadosArranjo)[IDarranjo].tipoEquipamento==2){
                        contadorCargas = 0;
                        cargaEncontrada = False;
                        while(!cargaEncontrada && contadorCargas<numeroCargas){
                            if((*dadosCarga)[contadorCargas].numero == numeroShunt){
                                (*dadosArranjo)[IDarranjo].IDshunt = (*dadosCarga)[contadorCargas].IDcarga;
                                (*dadosCarga)[contadorCargas].IDmedidor = IDarranjo;
                                cargaEncontrada = True;
                                //printf("\nArranjo: %d, carga: %d", IDarranjo, (*dadosCarga)[contadorCargas].IDcarga);
                            }
                            contadorCargas++;
                        }
                    }
                    else if((*dadosArranjo)[IDarranjo].tipoEquipamento==3){
                        contadorShunts = 0;
                        shuntEncontrado = False;
                        while(!shuntEncontrado && contadorShunts<numeroShunts){
                            if((*dadosShunt)[contadorShunts].numero == numeroShunt){
                                (*dadosArranjo)[IDarranjo].IDshunt = (*dadosShunt)[contadorShunts].IDshunt;
                                (*dadosShunt)[contadorShunts].IDmedidor = IDarranjo;
                                shuntEncontrado = True;
                            }
                            contadorShunts++;
                        }
                    }
                    else if((*dadosArranjo)[IDarranjo].tipoEquipamento==4){
                        contadorGeradores = 0;
                        geradorEncontrado = False;
                        while(!geradorEncontrado && contadorGeradores<numeroGeradores){
                            if((*dadosGerador)[contadorGeradores].numero == numeroShunt){
                                (*dadosArranjo)[IDarranjo].IDshunt = (*dadosGerador)[contadorGeradores].IDgerador;
                                (*dadosGerador)[contadorGeradores].IDmedidor = IDarranjo;
                                geradorEncontrado = True;
                            }
                            contadorGeradores++;
                        }
                    }
                }
                barraParaEncontrada = False;
                barraDeEncontrada = False;
                contadorBarras = 0;
                while((!barraDeEncontrada || !barraParaEncontrada || !barraLTRencontrada) && contadorBarras<numeroBarras){
                    if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[IDarranjo].TC.barraDe){
                        (*dadosArranjo)[IDarranjo].TC.IDbarraDe = (*dadosBarra)[contadorBarras].IDbarra;
                        barraDeEncontrada = True;
                        if((*dadosArranjo)[IDarranjo].TC.IDbarraDe != (*dadosArranjo)[IDarranjo].TP.IDbarra){
                            (*dadosBarra)[contadorBarras].quantidadeMedidores++;
                        }
                    }
                    else if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[IDarranjo].TC.barraPara){
                        (*dadosArranjo)[IDarranjo].TC.IDbarraPara = (*dadosBarra)[contadorBarras].IDbarra;
                        barraParaEncontrada = True;
                    }
                    else if((*dadosBarra)[contadorBarras].numeroBarra == (*dadosArranjo)[IDarranjo].barraLTR){
                        (*dadosArranjo)[IDarranjo].IDbarraLTR = (*dadosBarra)[contadorBarras].IDbarra;
                        barraLTRencontrada = True;
                    }
                    contadorBarras++;
                }
            }
        }
    }
    numeroArranjos[0] = contadorArranjos;
}
//Função para ler os dados da rede elétrica
char *leituraDados(DBAR **dadosBarra, DRAM **dadosRamo, DCHAVE **dadosChave, DGEN **dadosGerador, DCARGA **dadosCarga,
                    DSHUNT **dadosShunt, DARRANJO **dadosArranjo, DSUBESTACAO **dadosSubestacao, int *numeroBarras,
                            int *numeroRamos, int *numeroChaves, int *numeroGeradores, int *numeroCargas,
                            int *numeroShunts, int *numeroArranjos, int *numeroSubestacoes, int arg){
    FILE *arquivo = NULL;
    char linha[1000], *pasta, *aux;
    pasta = (char *) malloc(1000 * sizeof(char));
    aux = (char *) malloc(1000 * sizeof(char));
    //printf("Inicio da leitura dos dados da rede eletrica\n");

    FILE *config = NULL;
    config = fopen("Configuracao.txt","r");
    if (config == NULL){
        printf("Erro ao abrir o arquivo de configuração\n");
        exit(1);
    }
    fgets(linha, 1000, config);
    pasta = getfield(linha, 1);
    printf("Pasta: %s\n", pasta);
    fclose(config);
    strcat(pasta, "/"); //Adiciona a barra no final da string
    
    strcpy(aux,pasta); //Copia a string "pasta" para "aux"
    //printf("\n\n\n%s",strcat(aux, "DBAR.csv"));
    //Leitura dos dados de Barra
    arquivo = fopen(strcat(aux, "DBAR.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DBAR.csv!!!\n");
        exit(1);
    }
    else{
        leituraDBAR(arquivo, dadosBarra, dadosSubestacao, numeroBarras, numeroSubestacoes);
        fclose(arquivo);
        printf("\nQuantidade de barras: %d", *numeroBarras);
    }
    //Leitura dos dados de Ramo
    strcpy(aux, pasta);
    arquivo = fopen(strcat(aux, "DRAM.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DRAM.csv!!!\n");
        exit(1);
    }
    else{
        leituraDRAM(arquivo, dadosRamo, dadosBarra, numeroRamos, *numeroBarras);
        fclose(arquivo);
        printf("\nQuantidade de ramos: %d", *numeroRamos);
    }
    //Leitura dos dados de Chave
    strcpy(aux, pasta);
    arquivo = fopen(strcat(aux, "DCHAV.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DCHAV.csv!!!\n");
        exit(1);
    }
    else{
        leituraDCHAV(arquivo, dadosChave, dadosBarra, dadosSubestacao, numeroChaves, *numeroBarras);
        fclose(arquivo);
        printf("\nQuantidade de chaves: %d", *numeroChaves);
    }
    //Leitura dos dados de Gerador
    strcpy(aux, pasta); 
    arquivo = fopen(strcat(aux, "DGEN.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DGEN.csv!!!\n");
        exit(1);
    }
    else{
        leituraDGEN(arquivo, dadosGerador, dadosBarra, dadosSubestacao, numeroGeradores, *numeroBarras);
        fclose(arquivo);
        printf("\nQuantidade de geradores: %d", *numeroGeradores);
    }
    //Leitura dos dados de Carga
    strcpy(aux, pasta);
    arquivo = fopen(strcat(aux, "DLOADS.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DLOADS.csv!!!\n");
        exit(1);
    }
    else{
        leituraDLOADS(arquivo, dadosCarga, dadosBarra, dadosSubestacao, numeroCargas, *numeroBarras);
        fclose(arquivo);
        printf("\nQuantidade de cargas: %d", *numeroCargas);
    }
    //Leitura dos dados de Shunt
    strcpy(aux, pasta);
    arquivo = fopen(strcat(aux, "DSHUNT.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DSHUNT.csv!!!\n");
        exit(1);
    }
    else{
        leituraDSHUNT(arquivo, dadosShunt, dadosBarra, dadosSubestacao, numeroShunts, *numeroBarras);
        fclose(arquivo);
        printf("\nQuantidade de shunts: %d", *numeroShunts);
    }
    //Leitura dos dados de Arranjo de medição
    strcpy(aux, pasta); 
    arquivo = fopen(strcat(aux, "DARRANJ.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DARRANJ.csv!!!\n");
        exit(1);
    }
    else{
        leituraDARRANJ(arquivo, dadosArranjo, dadosBarra, dadosSubestacao, dadosGerador, dadosCarga, dadosShunt, numeroArranjos, *numeroBarras, *numeroGeradores, *numeroCargas, *numeroShunts);
        fclose(arquivo);
        printf("\nQuantidade de arranjos: %d", *numeroArranjos);
    }
    strcpy(aux, pasta);
    arquivo = fopen(strcat(aux, "DCHAV_ATUALIZADO.csv"), "r");
    if (arquivo == NULL){
        printf("Erro ao abrir o arquivo DCHAV_ATUALIZADO.csv!!!\n");
        exit(1);
    }
    else{
        leituraDCHAVATUALIZADO(arquivo, dadosChave, arg);
        fclose(arquivo);
        printf("\nStatus atualizado das chaves\n");
    }
    return pasta;
}